// @ts-nocheck
import React from "react";
import TestRenderer, { act } from "react-test-renderer";
import { useQueries, useQuery } from "@tanstack/react-query";
import { TeacherAssessmentDetailScreen } from "../TeacherAssessmentDetailScreen";
import { TeacherHomeScreen } from "../TeacherHomeScreen";
import { TeacherProfileScreen } from "../TeacherProfileScreen";
import { useAuth } from "../../providers/AuthProvider";
import {
  useAssessmentDetail,
  useTeacherAssessmentUpdateMutation,
  useTeacherAssessmentSubmissions,
  useTeacherClasses,
  useTeacherProfile,
  useTeacherProfileAvatarMutation,
  useTeacherProfileUpdateMutation,
} from "../../api/hooks";

jest.mock("@tanstack/react-query", () => ({
  useQueries: jest.fn(),
  useQuery: jest.fn(),
}));

jest.mock("react-native", () => {
  const ReactRuntime = require("react");
  const component = (name: string) => (props: Record<string, unknown>) =>
    ReactRuntime.createElement(name, props, props.children);

  return {
    View: component("View"),
    Text: component("Text"),
    Pressable: component("Pressable"),
    ScrollView: component("ScrollView"),
    TextInput: component("TextInput"),
    Image: component("Image"),
    Modal: component("Modal"),
    Alert: { alert: jest.fn() },
  };
});

jest.mock("@expo/vector-icons", () => {
  const ReactRuntime = require("react");
  return {
    MaterialCommunityIcons: (props: Record<string, unknown>) =>
      ReactRuntime.createElement("MaterialCommunityIcons", props, null),
  };
});

jest.mock("expo-image-picker", () => ({
  launchImageLibraryAsync: jest
    .fn()
    .mockResolvedValue({ canceled: true, assets: [] }),
  requestMediaLibraryPermissionsAsync: jest
    .fn()
    .mockResolvedValue({ granted: true }),
  MediaTypeOptions: { Images: "Images" },
}));

jest.mock("expo-application", () => ({
  nativeApplicationVersion: "0.1.16",
  nativeBuildVersion: "17",
}));

jest.mock("../../components/ui/primitives", () => {
  const ReactRuntime = require("react");
  const component = (name: string) => (props: Record<string, unknown>) =>
    ReactRuntime.createElement(name, props, props.children);
  return {
    Refreshable: component("Refreshable"),
    ScreenScroll: component("ScreenScroll"),
  };
});

jest.mock("../../components/account/PasswordChangeForm", () => {
  const ReactRuntime = require("react");
  return {
    PasswordChangeForm: () => ReactRuntime.createElement("PasswordChangeForm"),
  };
});

jest.mock("../../components/teacher/TeacherMobilePrimitives", () => {
  const ReactRuntime = require("react");
  const component = (name: string) => (props: Record<string, unknown>) =>
    ReactRuntime.createElement(name, props, props.children);
  const Text = component("Text");

  return {
    teacherTheme: {
      red: "#DC2626",
      green: "#166534",
      amber: "#B45309",
      blue: "#1E40AF",
      muted: "#64748B",
      dim: "#757684",
      text: "#191C1E",
      border: "#E2E8F0",
      border2: "#C4C5D5",
      surface: "#FFFFFF",
      surface2: "#F2F4F6",
      redSoft: "#FFF1F2",
      redLine: "rgba(220,38,38,0.28)",
      greenSoft: "#DCFCE7",
      greenLine: "rgba(22,101,52,0.22)",
      amberSoft: "#FEF3C7",
      blueSoft: "#D0E1FB",
      purpleSoft: "#DAE2FD",
      active: "#F2F4F6",
      header: "#FFFFFF",
    },
    stripRichText: (value?: string) => value || "",
    TeacherScreen: ({ title, children }: any) =>
      ReactRuntime.createElement(
        "TeacherScreen",
        null,
        ReactRuntime.createElement(Text, null, title),
        children,
      ),
    TeacherPanel: ({ title, subtitle, children }: any) =>
      ReactRuntime.createElement(
        "TeacherPanel",
        null,
        title ? ReactRuntime.createElement(Text, null, title) : null,
        subtitle ? ReactRuntime.createElement(Text, null, subtitle) : null,
        children,
      ),
    TeacherAccordionSection: ({
      title,
      count,
      expanded,
      action,
      children,
      onToggle,
    }: any) =>
      ReactRuntime.createElement(
        "TeacherAccordionSection",
        { title, count, expanded, onToggle },
        ReactRuntime.createElement(
          Text,
          null,
          `${title}${count === undefined ? "" : `:${count}`}`,
        ),
        action,
        expanded ? children : null,
      ),
    TeacherSelectMenu: ({ label, selectedValue }: any) =>
      ReactRuntime.createElement(
        "TeacherSelectMenu",
        null,
        ReactRuntime.createElement(Text, null, `${label}:${selectedValue}`),
      ),
    TeacherStats: ({ items }: any) =>
      ReactRuntime.createElement(
        "TeacherStats",
        null,
        items.map((item: any) =>
          ReactRuntime.createElement(
            Text,
            { key: item.label },
            `${item.label}:${item.value}`,
          ),
        ),
      ),
    TeacherChip: ({ label }: any) =>
      ReactRuntime.createElement(Text, null, label),
    TeacherActionButton: ({ label, onPress }: any) =>
      ReactRuntime.createElement(
        "Pressable",
        { accessibilityLabel: label, onPress },
        ReactRuntime.createElement(Text, null, label),
      ),
    TeacherEmpty: ({ title, subtitle }: any) =>
      ReactRuntime.createElement(
        "TeacherEmpty",
        null,
        ReactRuntime.createElement(Text, null, title),
        ReactRuntime.createElement(Text, null, subtitle),
      ),
    TeacherRow: ({ title, subtitle, right }: any) =>
      ReactRuntime.createElement(
        "TeacherRow",
        null,
        ReactRuntime.createElement(Text, null, title),
        subtitle ? ReactRuntime.createElement(Text, null, subtitle) : null,
        right,
      ),
    TeacherSearch: component("TeacherSearch"),
    TeacherInlineField: ({ label, value }: any) =>
      ReactRuntime.createElement(
        "TeacherInlineField",
        null,
        ReactRuntime.createElement(Text, null, label),
        ReactRuntime.createElement(Text, null, value),
      ),
  };
});

jest.mock("../../components/teacher/TeacherWorkspacePrimitives", () => {
  const ReactRuntime = require("react");
  const component = (name: string) => (props: Record<string, unknown>) =>
    ReactRuntime.createElement(name, props, props.children);
  const Text = component("Text");
  const Pressable = component("Pressable");

  return {
    TeacherContextStrip: ({ title, subtitle, status }: any) =>
      ReactRuntime.createElement(
        "TeacherContextStrip",
        null,
        ReactRuntime.createElement(Text, null, title),
        subtitle ? ReactRuntime.createElement(Text, null, subtitle) : null,
        status ? ReactRuntime.createElement(Text, null, status) : null,
      ),
    TeacherSegmentedTabs: ({ items, activeKey, onSelect }: any) =>
      ReactRuntime.createElement(
        "TeacherSegmentedTabs",
        null,
        items.map((item: any) =>
          ReactRuntime.createElement(
            Pressable,
            {
              key: item.key,
              accessibilityLabel: item.label,
              onPress: () => onSelect(item.key),
              active: item.key === activeKey,
            },
            ReactRuntime.createElement(Text, null, item.label),
          ),
        ),
      ),
    TeacherActionSheet: ({ visible, title, children }: any) =>
      visible
        ? ReactRuntime.createElement(
            "TeacherActionSheet",
            null,
            ReactRuntime.createElement(Text, null, title),
            children,
          )
        : null,
    TeacherFlatSection: ({ title, subtitle, action, children }: any) =>
      ReactRuntime.createElement(
        "TeacherFlatSection",
        null,
        ReactRuntime.createElement(Text, null, title),
        subtitle ? ReactRuntime.createElement(Text, null, subtitle) : null,
        action,
        children,
      ),
    TeacherSummaryStrip: ({ items }: any) =>
      ReactRuntime.createElement(
        "TeacherSummaryStrip",
        null,
        items.map((item: any) =>
          ReactRuntime.createElement(
            Text,
            { key: item.label },
            `${item.label}:${item.value}`,
          ),
        ),
      ),
  };
});

jest.mock("../../api/config", () => ({
  API_BASE_URL: "http://localhost:3000/api",
}));

jest.mock("../../api/services/mobile-workspace", () => ({
  mobileWorkspaceApi: {
    getTeacherOverviewForUser: jest.fn(),
  },
}));

jest.mock("../../api/services/announcements", () => ({
  announcementsApi: {
    getByClass: jest.fn(),
  },
}));

jest.mock("../../api/services/assessments", () => ({
  assessmentsApi: {
    getByClass: jest.fn(),
    openTeacherAttachment: jest.fn(),
  },
}));

jest.mock("../../api/services/performance", () => ({
  performanceApi: {
    getClassAtRisk: jest.fn(),
  },
}));

jest.mock("../../providers/AuthProvider", () => ({
  useAuth: jest.fn(),
}));

jest.mock("../../api/hooks", () => ({
  queryKeys: {
    assessments: (classId: string) => ["assessments", classId],
    announcements: (classId: string) => ["announcements", classId],
    teacherClassAtRisk: (classId: string) => ["teacher-class-at-risk", classId],
    mobileTeacherOverview: ["mobile-workspace", "teacher", "overview"],
  },
  useTeacherClasses: jest.fn(),
  useAssessmentDetail: jest.fn(),
  useTeacherAssessmentUpdateMutation: jest.fn(),
  useTeacherDeleteAssessmentMutation: jest.fn(() => ({
    mutate: jest.fn(),
    isPending: false,
  })),
  useTeacherAssessmentSubmissions: jest.fn(),
  useTeacherProfile: jest.fn(),
  useTeacherProfileUpdateMutation: jest.fn(),
  useTeacherProfileAvatarMutation: jest.fn(),
}));

const mockedUseQueries = useQueries as jest.Mock;
const mockedUseQuery = useQuery as jest.Mock;
const mockedUseAuth = useAuth as jest.Mock;
const mockedUseTeacherClasses = useTeacherClasses as jest.Mock;
const mockedUseAssessmentDetail = useAssessmentDetail as jest.Mock;
const mockedUseTeacherAssessmentUpdateMutation =
  useTeacherAssessmentUpdateMutation as jest.Mock;
const mockedUseTeacherAssessmentSubmissions =
  useTeacherAssessmentSubmissions as jest.Mock;
const mockedUseTeacherProfile = useTeacherProfile as jest.Mock;
const mockedUseTeacherProfileUpdateMutation =
  useTeacherProfileUpdateMutation as jest.Mock;
const mockedUseTeacherProfileAvatarMutation =
  useTeacherProfileAvatarMutation as jest.Mock;

(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true;

function flattenText(
  node:
    | TestRenderer.ReactTestRendererJSON
    | TestRenderer.ReactTestRendererJSON[]
    | null,
): string {
  if (!node) return "";
  if (Array.isArray(node)) return node.map(flattenText).join(" ");
  const children = Array.isArray(node.children)
    ? node.children
        .map((child) =>
          typeof child === "string" ? child : flattenText(child),
        )
        .join(" ")
    : "";
  return children;
}

describe("teacher mobile screens", () => {
  beforeEach(() => {
    mockedUseQueries.mockReturnValue([]);
    mockedUseQuery.mockImplementation(
      ({ queryKey }: { queryKey: string[] }) => ({
        data: queryKey.includes("mobile-workspace")
          ? {
              classes: [
                {
                  id: "class-1",
                  subjectCode: "INF234",
                  subjectName: "Capstone",
                  section: { id: "section-1", name: "12-A", gradeLevel: "12" },
                  schoolYear: "2025-2026",
                  enrollmentCount: 32,
                  room: "ICT Lab",
                  schedules: [
                    {
                      id: "schedule-1",
                      days: ["W"],
                      startTime: "10:00",
                      endTime: "11:00",
                    },
                  ],
                },
                {
                  id: "class-2",
                  subjectCode: "ICT101",
                  subjectName: "Programming",
                  section: { id: "section-2", name: "11-B", gradeLevel: "11" },
                  schoolYear: "2025-2026",
                  enrollmentCount: 30,
                  schedules: [],
                },
                {
                  id: "class-3",
                  subjectCode: "EXTRA",
                  subjectName: "Third class",
                  section: { id: "section-3", name: "10-C", gradeLevel: "10" },
                  schoolYear: "2025-2026",
                  enrollmentCount: 28,
                  schedules: [],
                },
              ],
              assessments: [],
              announcements: [],
              atRiskCounts: {},
              generatedAt: new Date().toISOString(),
              requestBudget: { clientRequests: 1, dbQueries: 4 },
              offlineSnapshotReadsEnabled: true,
            }
          : queryKey.includes("teacher-assessment-stats")
            ? {
                totalAttempts: 1,
                submittedAttempts: 1,
                averageScore: 88,
                highestScore: 88,
                lowestScore: 88,
                passRate: 100,
                averageTimeSeconds: 120,
                completionRate: 100,
                totalEnrolled: 1,
              }
            : { totalResponses: 1, uniqueSubmitterCount: 1, questions: [] },
        isError: false,
        error: null,
        isRefetching: false,
        refetch: jest.fn(),
      }),
    );
    mockedUseAuth.mockReturnValue({
      user: {
        id: "teacher-1",
        userId: "teacher-1",
        email: "teacher@nexora.test",
        firstName: "Teacher",
        lastName: "One",
      },
      logout: jest.fn(),
    });
  });

  it("renders the teacher home as the approved agenda-and-class overview", () => {
    mockedUseTeacherClasses.mockReturnValue({
      data: [
        {
          id: "class-1",
          subjectCode: "INF234",
          subjectName: "Capstone",
          section: { name: "12-A" },
          schoolYear: "2025-2026",
          enrollmentCount: 32,
          room: "ICT Lab",
          schedules: [
            {
              id: "schedule-1",
              days: ["W"],
              startTime: "10:00",
              endTime: "11:00",
            },
          ],
        },
        {
          id: "class-2",
          subjectCode: "ICT101",
          subjectName: "Programming",
          section: { name: "11-B" },
          schoolYear: "2025-2026",
          enrollmentCount: 30,
        },
        {
          id: "class-3",
          subjectCode: "EXTRA",
          subjectName: "Third class",
          section: { name: "10-C" },
          schoolYear: "2025-2026",
          enrollmentCount: 28,
        },
      ],
      isRefetching: false,
      refetch: jest.fn(),
    });

    let renderer: TestRenderer.ReactTestRenderer;
    act(() => {
      renderer = TestRenderer.create(
        <TeacherHomeScreen
          navigation={{ navigate: jest.fn() } as never}
          route={{ key: "Home", name: "Home" } as never}
        />,
      );
    });

    const text = flattenText(renderer.toJSON());
    expect(text).toContain("Teacher Home");
    expect(
      renderer.root.findAll((node) => node.type === "TeacherStats"),
    ).toHaveLength(0);
    expect(
      renderer.root.findAll((node) => node.type === "TeacherAccordionSection"),
    ).toHaveLength(0);
    expect(
      renderer.root.findAll((node) => node.type === "TeacherActionButton"),
    ).toHaveLength(0);
    expect(text).toContain("Next up");
    expect(text).toContain("Today");
    expect(text).toContain("Priority");
    expect(text).toContain("Your classes");
    expect(text).toContain("Recent update");
    expect(text.indexOf("Next up")).toBeLessThan(text.indexOf("Today"));
    expect(text.indexOf("Today")).toBeLessThan(text.indexOf("Priority"));
    expect(text.indexOf("Priority")).toBeLessThan(text.indexOf("Your classes"));
    expect(text).toContain("INF234");
    expect(text).toContain("ICT101");
    expect(text).not.toContain("EXTRA");
    expect(text).not.toContain("Needs attention");
    expect(text).not.toContain("Intervention focus");
  });

  it("renders teacher assessment detail with submissions", () => {
    mockedUseAssessmentDetail.mockReturnValue({
      data: {
        id: "assessment-1",
        classId: "class-1",
        title: "Quarter Quiz",
        type: "quiz",
        isPublished: true,
        dueDate: "2026-05-08T08:00:00.000Z",
        questions: [{ id: "q1" }],
      },
      isRefetching: false,
      refetch: jest.fn(),
    });
    mockedUseTeacherAssessmentSubmissions.mockReturnValue({
      data: {
        summary: {
          total: 1,
          notStarted: 0,
          inProgress: 0,
          turnedIn: 1,
          returned: 0,
        },
        submissions: [
          {
            studentId: "student-1",
            studentName: "Student One",
            status: "turned_in",
            latestAttemptId: "attempt-1",
          },
        ],
      },
      isRefetching: false,
      refetch: jest.fn(),
    });
    mockedUseTeacherAssessmentUpdateMutation.mockReturnValue({
      mutateAsync: jest.fn(),
      isPending: false,
    });

    let renderer: TestRenderer.ReactTestRenderer;
    act(() => {
      renderer = TestRenderer.create(
        <TeacherAssessmentDetailScreen
          navigation={{ goBack: jest.fn(), navigate: jest.fn() } as never}
          route={
            {
              key: "TeacherAssessmentDetail",
              name: "TeacherAssessmentDetail",
              params: { assessmentId: "assessment-1", classId: "class-1" },
            } as never
          }
        />,
      );
    });

    let text = flattenText(renderer.toJSON());
    expect(text).toContain("Quarter Quiz");
    expect(text).toContain("Submissions");
    act(() => {
      renderer.root
        .findByProps({ accessibilityLabel: "Submissions" })
        .props.onPress();
    });
    text = flattenText(renderer.toJSON());
    expect(text).toContain("Student One");
  });

  it("renders the teacher profile screen against teacher profile data", () => {
    mockedUseTeacherProfile.mockReturnValue({
      data: {
        id: "profile-1",
        userId: "teacher-1",
        department: "ICT",
        specialization: "Software",
        employeeId: "EMP-001",
        phone: "09123456789",
        address: "Manila",
      },
      isRefetching: false,
      refetch: jest.fn(),
    });
    mockedUseTeacherProfileUpdateMutation.mockReturnValue({
      mutateAsync: jest.fn(),
      isPending: false,
    });
    mockedUseTeacherProfileAvatarMutation.mockReturnValue({
      mutateAsync: jest.fn(),
      isPending: false,
    });

    let renderer: TestRenderer.ReactTestRenderer;
    act(() => {
      renderer = TestRenderer.create(
        <TeacherProfileScreen
          navigation={{ navigate: jest.fn() } as never}
          route={{ key: "Profile", name: "Profile" } as never}
        />,
      );
    });

    const professionalSection = renderer.root.find(
      (node) =>
        node.type === "TeacherAccordionSection" &&
        node.props.title === "Professional details",
    );
    act(() => professionalSection.props.onToggle());

    const text = flattenText(renderer.toJSON());
    expect(text).toContain("Teacher One");
    expect(text).toContain("ICT");
    expect(text).toContain("Employee ID");
    expect(
      renderer.root.findAll((node) => node.type === "TeacherStats"),
    ).toHaveLength(0);
    expect(text).not.toContain("teacher profile API");
    expect(text).toContain("Contact details");
    expect(text).toContain("Professional details");
    expect(text.indexOf("Nexora Mobile")).toBeLessThan(text.indexOf("Log out"));
  });
});
