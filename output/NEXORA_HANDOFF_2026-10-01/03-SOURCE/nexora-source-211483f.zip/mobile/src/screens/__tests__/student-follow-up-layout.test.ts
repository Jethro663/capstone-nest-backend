import fs from "node:fs";
import path from "node:path";

function read(relativePath: string) {
  return fs.readFileSync(path.resolve(__dirname, relativePath), "utf8");
}

describe("student mobile follow-up layout contracts", () => {
  it("keeps Home readable on stable surfaces and separates the learning sections", () => {
    const source = read("../student-home/StudentHomeView.tsx");

    expect(source).toContain('require("../../../assets/ja/ja_cheer.png")');
    expect(source).toContain('testID="student-home-ja"');
    expect(source).toContain("buildStudentHomeAgenda");
    expect(source).toContain('testID="student-home-priority-surface"');
    expect(source).toContain('testID="student-home-section-divider"');
    expect(source).toContain("styles.priorityBody");
    expect(source).toContain("styles.sectionDivider");
    expect(source).toContain("styles.moveStack");
    expect(source).toContain('eyebrow="Keep momentum"');
    expect(source).toContain('title="School bulletin"');
    expect(source).toContain("styles.followUpRail");
    expect(source).toContain("styles.momentumCard");
    expect(source).toContain("styles.updateBody");
    expect(source).toContain("StudentNextMoveRow");
    expect(source).not.toContain("styles.moveGrid");
    expect(source).not.toContain("function MoveTile");
    expect(source).not.toContain('priorityKicker: { color: "#FECACA"');
    expect(source).not.toContain(
      'priorityTitle: { marginTop: 15, color: "#FFFFFF"',
    );
  });

  it("matches the web class header hierarchy while bounding mobile actions", () => {
    const source = read("../student-classes/StudentClassCard.tsx");

    expect(source).toContain('testID="student-class-hero-surface"');
    expect(source).toContain(
      'import { LinearGradient } from "expo-linear-gradient"',
    );
    expect(source).toContain(
      "colors={[mobileBrand.navy, mobileBrand.navyRaised]}",
    );
    expect(source).toContain("styles.heroStatusRow");
    expect(source).toContain("styles.heroIdentity");
    expect(source).toContain(
      "Grade {classItem.subjectGradeLevel} • {classItem.sectionName}",
    );
    expect(source).toContain("with {classItem.teacherName}");
    expect(source).not.toContain("{classItem.subjectCode}");
    expect(source).toContain(": classItem.progress > 0");
    expect(source).not.toContain("classItem.totalLessons === 0");
    expect(source.indexOf("styles.statusPill")).toBeLessThan(
      source.indexOf("styles.subjectName"),
    );
    expect(source).toMatch(/hero:\s*\{[^}]*paddingHorizontal:\s*18/);
    expect(source).toContain("styles.heroPressTarget");
    expect(source).not.toContain("styles.actionSurface");
    expect(source).not.toContain("styles.primaryActionSurface");
    expect(source).toContain("styles.secondaryActionRow");
    expect(source.indexOf("styles.primaryButton")).toBeLessThan(
      source.indexOf("styles.secondaryActionRow"),
    );
    expect(source).toContain("styles.actionIconSlot");
    expect(source).toContain("styles.actionTrailingSlot");
    expect(source).toContain('accessibilityLabel="View tasks"');
    expect(source).toContain('accessibilityLabel="View schedule"');
    expect(source).toMatch(/>\s*Tasks\s*<\/Text>/);
    expect(source).toMatch(/>\s*Schedule\s*<\/Text>/);
    expect(source).toContain(
      "numberOfLines={2} style={styles.primaryButtonText}",
    );
    expect(source).not.toContain("const heroColor = index % 2");
  });

  it("uses the shared student shell and a compact facts ledger for assessment work", () => {
    const source = read("../AssessmentDetailScreen.tsx");

    expect(source).toContain("StudentScreen");
    expect(source).toContain("StudentContextStrip");
    expect(source).toContain("StudentFlatSection");
    expect(source).toContain("StudentBottomActionBar");
    expect(source).toContain("function AssessmentFactsLedger");
    expect(source).toContain('testID="assessment-facts-ledger"');
    expect(source).not.toContain("function MetricTile");
    expect(source).not.toContain("<MetricTile");
    expect(source).toContain('title="Assessment details"');
    expect(source).toContain('title="Latest activity"');
    expect(source).toContain('title="My work"');
  });

  it("disables swipe dismissal for the active assessment route", () => {
    const source = read("../../navigation/AppNavigator.tsx");
    const assessmentRoute = source.slice(
      source.indexOf('case "AssessmentTake"'),
      source.indexOf('case "AssessmentResults"'),
    );

    expect(assessmentRoute).toContain("gestureEnabled: false");
  });
});
