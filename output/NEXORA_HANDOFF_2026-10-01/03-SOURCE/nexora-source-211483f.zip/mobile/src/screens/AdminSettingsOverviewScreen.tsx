import { useQuery } from "@tanstack/react-query";
import type { BottomTabScreenProps } from "@react-navigation/bottom-tabs";
import { academicStateService } from "../api/services/academic-state";
import { systemCapabilitiesApi } from "../api/services/system-capabilities";
import { AdminAsyncState } from "../components/admin/AdminAsyncState";
import {
  AdminAdaptiveColumns,
  AdminDataRow,
  AdminEmpty,
  AdminNotice,
  AdminScreen,
  AdminSection,
} from "../components/admin/AdminMobilePrimitives";
import type { MainTabParamList, RootStackParamList } from "../navigation/types";
import { adminSettingsTaskRoutes } from "../navigation/admin-route-manifest";
import type { SystemCapabilityEntry } from "../types/system-capabilities";

type Props = BottomTabScreenProps<MainTabParamList, "AdminSettings">;

function capabilityLabel(state: SystemCapabilityEntry["state"]) {
  return `${state.charAt(0).toUpperCase()}${state.slice(1)}`;
}

function capabilityTone(state: SystemCapabilityEntry["state"]) {
  if (state === "active" || state === "ready") return "green" as const;
  if (state === "degraded" || state === "inactive") return "amber" as const;
  return "red" as const;
}

export function AdminSettingsOverviewScreen({ navigation }: Props) {
  const current = useQuery({
    queryKey: ["academic", "current"],
    queryFn: async () => (await academicStateService.getCurrent()).data,
  });
  const readiness = useQuery({
    queryKey: ["academic", "readiness"],
    queryFn: async () => (await academicStateService.getReadiness()).data,
  });
  const capabilities = useQuery({
    queryKey: ["system", "capabilities"],
    queryFn: () => systemCapabilitiesApi.getSnapshot(),
  });
  const root = navigation.getParent() as unknown as {
    navigate: <Name extends keyof RootStackParamList>(
      name: Name,
      params?: RootStackParamList[Name],
    ) => void;
  };
  const open = (
    name:
      | "AdminSettingsAcademicYear"
      | "AdminSettingsAssessmentsGrading"
      | "AdminSettingsYearTransition"
      | "AdminSettingsLearnerCompletion"
      | "AdminSettingsAuditRecovery"
      | "AdminSettingsMaintenance"
      | "AdminSettingsResetSchoolData"
      | "AdminStudentReadiness",
  ) => root.navigate(name);
  const blockers = readiness.data?.blockers.length ?? 0;
  return (
    <AdminScreen
      title="System Settings"
      subtitle="Start with the current academic state, then enter one bounded task"
      refreshing={current.isRefetching || readiness.isRefetching || capabilities.isRefetching}
      onRefresh={() => {
        void current.refetch();
        void readiness.refetch();
        void capabilities.refetch();
      }}
    >
      {current.isError ? (
        <AdminNotice
          title="Academic state unavailable"
          description="Open Audit & Recovery to inspect duplicate or invalid state evidence."
          tone="red"
        />
      ) : (
        <AdminNotice
          title={
            current.data
              ? `${current.data.schoolYear} · ${current.data.periods.find((period) => period.key === current.data?.quarter)?.label ?? current.data?.quarter}`
              : "Loading current state"
          }
          description={`${blockers} readiness blocker${blockers === 1 ? "" : "s"}. No setting changes from this overview.`}
          tone={blockers ? "amber" : "green"}
        />
      )}
      <AdminSection
        title="Live system capabilities"
        subtitle="Backend-owned availability and health evidence"
      >
        <AdminAsyncState
          isLoading={capabilities.isLoading}
          hasData={Boolean(capabilities.data)}
          error={
            capabilities.isError
              ? capabilities.error instanceof Error
                ? capabilities.error.message
                : "Capability snapshot unavailable"
              : null
          }
          onRetry={() => void capabilities.refetch()}
          isRetrying={capabilities.isRefetching}
          empty={
            <AdminEmpty
              title="No capability evidence"
              subtitle="The backend returned no capability snapshot."
            />
          }
        >
          {capabilities.data
            ? (
                [
                  ["Academic operations", capabilities.data.capabilities.academicOperations],
                  ["Maintenance access", capabilities.data.capabilities.maintenanceAccess],
                  ["System readiness", capabilities.data.capabilities.systemReadiness],
                  ["Workflow diagnostics", capabilities.data.capabilities.workflowDiagnostics],
                ] as const
              ).map(([title, entry]) => (
                <AdminDataRow
                  key={title}
                  title={title}
                  subtitle={entry.reasonCode ?? `Reported by ${entry.source}`}
                  status={capabilityLabel(entry.state)}
                  statusTone={capabilityTone(entry.state)}
                />
              ))
            : null}
        </AdminAsyncState>
      </AdminSection>
      <AdminAdaptiveColumns
        primary={
          <AdminSection
            title="Routine settings"
            subtitle="Review before changing the active academic context"
          >
            <AdminDataRow
              title="Academic Year"
              subtitle="Review the current policy periods and activate a verified grading period"
              onPress={() => open("AdminSettingsAcademicYear")}
            />
            <AdminDataRow
              title="Assessments & Grading"
              subtitle="Open class workbooks and grading evidence"
              onPress={() => open("AdminSettingsAssessmentsGrading")}
            />
            <AdminDataRow
              title="Student Academic Readiness"
              subtitle="Review each learner's complete annual evidence and blockers"
              onPress={() => open("AdminStudentReadiness")}
            />
          </AdminSection>
        }
        secondary={
          <AdminSection
            title="Consequential settings"
            subtitle="Preview and evidence are required before mutations"
          >
            <AdminDataRow
              title="Year Transition"
              subtitle="Preview blockers, authenticate, confirm, then execute"
              status={blockers ? `${blockers} blockers` : "Ready to review"}
              statusTone={blockers ? "amber" : "green"}
              onPress={() => open("AdminSettingsYearTransition")}
            />
            <AdminDataRow
              title="Learner Completion"
              subtitle="Schedule back subjects, record clearance, and verify Grade 10 completion"
              onPress={() => open("AdminSettingsLearnerCompletion")}
            />
            <AdminDataRow
              title="Audit & Recovery"
              subtitle="Audit first; repair only from manifest-bound evidence"
              onPress={() => open("AdminSettingsAuditRecovery")}
            />
          </AdminSection>
        }
      />
      <AdminSection
        title="Testing tools"
        subtitle="Consequential tools for demonstrations and fresh school setup"
      >
        <AdminDataRow
          title="Maintenance Access"
          subtitle="Open a short, audited academic cleanup window"
          status="Advanced"
          statusTone="red"
          onPress={() => open("AdminSettingsMaintenance")}
        />
        <AdminDataRow
          title="Reset school data"
          subtitle="Preview what is cleared and kept, then confirm a permanent reset"
          status="Irreversible"
          statusTone="red"
          onPress={() => open(adminSettingsTaskRoutes.resetSchoolData)}
        />
      </AdminSection>
    </AdminScreen>
  );
}
