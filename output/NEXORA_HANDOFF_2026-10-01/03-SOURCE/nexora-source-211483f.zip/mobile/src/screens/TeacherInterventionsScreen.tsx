import { useEffect, useMemo, useState } from "react";
import { Text, View } from "react-native";
import { AppAlert as Alert } from "../components/ui/AppAlert";
import {
  useTeacherClasses,
  useTeacherInterventionClassReport,
  useTeacherInterventionsHistory,
  useTeacherInterventionsQueue,
  useTeacherPendingInterventions,
} from "../api/hooks";
import { lxpApi } from "../api/services/lxp";
import { toAppError } from "../api/http";
import type { TeacherDrawerScreenProps } from "../navigation/types";
import { useAuth } from "../providers/AuthProvider";
import { boundAcademicPercentage } from "../lib/academicScore";
import type {
  LxpClassReport,
  TeacherInterventionCase,
  TeacherInterventionHistoryRow,
} from "../types/teacher";
import { TeacherInterventionWorkspaceContent } from "./TeacherDeepParityScreens";
import {
  TeacherActionButton,
  TeacherEmpty,
  TeacherRow,
  TeacherScreen,
  TeacherSearch,
  TeacherSelectMenu,
  teacherTheme,
} from "../components/teacher/TeacherMobilePrimitives";
import {
  TeacherFlatSection,
  TeacherSegmentedTabs,
  TeacherSummaryStrip,
} from "../components/teacher/TeacherWorkspacePrimitives";

type Props = TeacherDrawerScreenProps<"TeacherInterventions">;
type WorkspaceView = "queue" | "overview" | "history";
type LeaderboardScope = "xp" | "streak" | "checkpoints";
type StatusFilter = "all" | "pending" | "active" | "completed" | "dismissed";
type SortMode = "newest" | "risk" | "progress";

const leaderboardOptions: Array<{ key: LeaderboardScope; label: string }> = [
  { key: "xp", label: "XP" },
  { key: "streak", label: "Streak" },
  { key: "checkpoints", label: "Checkpoints" },
];

function getErrorMessage(error: unknown) {
  return toAppError(error).message;
}

function personName(
  entry?: {
    firstName?: string | null;
    lastName?: string | null;
    email?: string | null;
  } | null,
): string {
  const first = entry?.firstName?.trim() ?? "";
  const last = entry?.lastName?.trim() ?? "";
  if (first && last) return `${last}, ${first}`;
  if (last) return last;
  if (first) return first;
  return entry?.email ?? "Student";
}

function caseName(entry: TeacherInterventionCase): string {
  return entry.studentName || personName(entry.student);
}

function formatPercent(value?: number | null) {
  return typeof value === "number"
    ? `${boundAcademicPercentage(value).toFixed(1)}%`
    : "--";
}

function formatDate(value?: string | null) {
  if (!value) return "Date unavailable";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Date unavailable";
  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function severityLabel(
  entry: Pick<TeacherInterventionCase, "triggerScore" | "thresholdApplied">,
) {
  if (entry.triggerScore == null || entry.thresholdApplied == null)
    return "Monitoring";
  const gap = entry.thresholdApplied - entry.triggerScore;
  if (gap >= 15) return "Critical";
  if (gap >= 5) return "Needs Focus";
  return "Monitoring";
}

function matchesSearch(text: string, query: string) {
  const trimmed = query.trim().toLowerCase();
  return !trimmed || text.toLowerCase().includes(trimmed);
}

function caseSearchText(entry: TeacherInterventionCase) {
  return [
    caseName(entry),
    entry.student?.email,
    entry.status,
    entry.className,
    entry.classCode,
  ]
    .filter(Boolean)
    .join(" ");
}

function historySearchText(row: TeacherInterventionHistoryRow) {
  return [
    personName(row.student),
    row.student?.email,
    row.status,
    row.triggerSource,
  ]
    .filter(Boolean)
    .join(" ");
}

function compareDates(left?: string | null, right?: string | null) {
  return new Date(right || 0).getTime() - new Date(left || 0).getTime();
}

function sortCases(rows: TeacherInterventionCase[], sortMode: SortMode) {
  return [...rows].sort((left, right) => {
    if (sortMode === "risk") {
      const leftGap =
        (left.thresholdApplied ?? 0) -
        (left.triggerScore ?? left.thresholdApplied ?? 0);
      const rightGap =
        (right.thresholdApplied ?? 0) -
        (right.triggerScore ?? right.thresholdApplied ?? 0);
      return rightGap - leftGap;
    }
    if (sortMode === "progress") {
      return (left.completionPercent ?? 0) - (right.completionPercent ?? 0);
    }
    return compareDates(left.openedAt, right.openedAt);
  });
}

function sortHistory(
  rows: TeacherInterventionHistoryRow[],
  sortMode: SortMode,
) {
  return [...rows].sort((left, right) => {
    if (sortMode === "risk") {
      const leftGap =
        left.thresholdApplied - (left.triggerScore ?? left.thresholdApplied);
      const rightGap =
        right.thresholdApplied - (right.triggerScore ?? right.thresholdApplied);
      return rightGap - leftGap;
    }
    if (sortMode === "progress") {
      return (
        left.completion.completionPercent - right.completion.completionPercent
      );
    }
    return compareDates(left.openedAt, right.openedAt);
  });
}

function useFilteredCases(
  rows: TeacherInterventionCase[],
  search: string,
  status: StatusFilter,
  sortMode: SortMode,
) {
  return useMemo(() => {
    const filtered = rows.filter((entry) => {
      const statusMatches =
        status === "all" || String(entry.status || "").toLowerCase() === status;
      return statusMatches && matchesSearch(caseSearchText(entry), search);
    });
    return sortCases(filtered, sortMode);
  }, [rows, search, sortMode, status]);
}

function scoreForLeaderboard(
  row: LxpClassReport["leaderboard"][number],
  scope: LeaderboardScope,
) {
  if (scope === "streak") return row.streakDays;
  if (scope === "checkpoints") return row.checkpointsCompleted;
  return row.xpTotal;
}

function labelForLeaderboard(
  row: LxpClassReport["leaderboard"][number],
  scope: LeaderboardScope,
) {
  if (scope === "streak") return `${row.streakDays} day streak`;
  if (scope === "checkpoints") return `${row.checkpointsCompleted} checkpoints`;
  return `${row.xpTotal} XP`;
}

export function TeacherInterventionsScreen({ navigation, route }: Props) {
  const { user } = useAuth();
  const teacherId = user?.userId || user?.id;
  const classesQuery = useTeacherClasses(teacherId);
  const [selectedClassId, setSelectedClassId] = useState<string>(
    route.params?.classId || "",
  );
  const [workspaceView, setWorkspaceView] = useState<WorkspaceView>("queue");
  const [leaderboardScope, setLeaderboardScope] =
    useState<LeaderboardScope>("xp");
  const [leaderboardExpanded, setLeaderboardExpanded] = useState(false);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [sortMode, setSortMode] = useState<SortMode>("newest");
  const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
  const [selectedHistoryRow, setSelectedHistoryRow] =
    useState<TeacherInterventionHistoryRow | null>(null);
  const [busyCaseId, setBusyCaseId] = useState<string | null>(null);

  useEffect(() => {
    if (!selectedClassId && classesQuery.data?.length) {
      setSelectedClassId(classesQuery.data[0].id);
    }
  }, [classesQuery.data, selectedClassId]);

  useEffect(() => {
    const routeClassId = route.params?.classId;
    if (!routeClassId) return;
    setSelectedClassId((current) =>
      current === routeClassId ? current : routeClassId,
    );
  }, [route.params?.classId]);

  const queueQuery = useTeacherInterventionsQueue(selectedClassId || undefined);
  const historyQuery = useTeacherInterventionsHistory(
    selectedClassId || undefined,
  );
  const reportQuery = useTeacherInterventionClassReport(
    selectedClassId || undefined,
  );
  const pendingQuery = useTeacherPendingInterventions();

  const queueItems = useMemo(
    () => queueQuery.data?.queue ?? [],
    [queueQuery.data?.queue],
  );
  const historyRows = useMemo(
    () => historyQuery.data?.history ?? [],
    [historyQuery.data?.history],
  );
  const report = reportQuery.data;
  const selectedClass = useMemo(
    () => classesQuery.data?.find((entry) => entry.id === selectedClassId),
    [classesQuery.data, selectedClassId],
  );

  const queueCaseByStudent = useMemo(() => {
    const map = new Map<string, string>();
    queueItems.forEach((entry) => {
      if (entry.studentId)
        map.set(entry.studentId, entry.id || entry.caseId || "");
      if (entry.student?.id)
        map.set(entry.student.id, entry.id || entry.caseId || "");
    });
    return map;
  }, [queueItems]);

  const visibleQueue = useFilteredCases(
    queueItems,
    search,
    statusFilter,
    sortMode,
  );
  const visibleHistory = useMemo(() => {
    const filtered = historyRows.filter((row) => {
      const statusMatches =
        statusFilter === "all" ||
        String(row.status || "").toLowerCase() === statusFilter;
      return statusMatches && matchesSearch(historySearchText(row), search);
    });
    return sortHistory(filtered, sortMode);
  }, [historyRows, search, sortMode, statusFilter]);

  const visibleOutcomes = useMemo(
    () =>
      (report?.rows ?? []).filter((row) => {
        const statusMatches =
          statusFilter === "all" ||
          String(row.status || "").toLowerCase() === statusFilter;
        const text = [personName(row.student), row.status]
          .filter(Boolean)
          .join(" ");
        return statusMatches && matchesSearch(text, search);
      }),
    [report?.rows, search, statusFilter],
  );

  const leaderboardRows = useMemo(() => {
    const rows = (report?.leaderboard ?? []).filter((row) =>
      matchesSearch(
        [personName(row.student), row.student?.email].filter(Boolean).join(" "),
        search,
      ),
    );
    return [...rows].sort(
      (left, right) =>
        scoreForLeaderboard(right, leaderboardScope) -
        scoreForLeaderboard(left, leaderboardScope),
    );
  }, [leaderboardScope, report?.leaderboard, search]);

  const shownLeaderboardRows = leaderboardExpanded
    ? leaderboardRows
    : leaderboardRows.slice(0, 5);
  const isRefreshing =
    classesQuery.isRefetching ||
    queueQuery.isRefetching ||
    historyQuery.isRefetching ||
    reportQuery.isRefetching ||
    pendingQuery.isRefetching;

  const refreshAll = async () => {
    const tasks: Array<Promise<unknown>> = [
      classesQuery.refetch(),
      pendingQuery.refetch(),
    ];
    if (selectedClassId) {
      tasks.push(
        queueQuery.refetch(),
        historyQuery.refetch(),
        reportQuery.refetch(),
      );
    }
    await Promise.all(tasks);
  };

  const runCaseAction = async (
    caseId: string,
    action: "activate" | "resolve" | "regenerate",
  ) => {
    try {
      setBusyCaseId(caseId);
      if (action === "activate") {
        await lxpApi.activateIntervention(caseId);
      } else if (action === "resolve") {
        await lxpApi.resolveIntervention(caseId, "Resolved by teacher queue");
        if (selectedCaseId === caseId) setSelectedCaseId(null);
      } else {
        const result = await lxpApi.regenerateInterventionPath(caseId);
        const nextCaseId = result.case.id || result.case.caseId || "";
        if (nextCaseId) {
          setSelectedCaseId(nextCaseId);
          setWorkspaceView("queue");
        }
      }
      await refreshAll();
    } catch (error) {
      Alert.alert("Unable to update intervention", getErrorMessage(error));
    } finally {
      setBusyCaseId(null);
    }
  };

  const openCaseWorkspace = (caseId?: string | null) => {
    if (!caseId) return;
    setSelectedHistoryRow(null);
    setSelectedCaseId(caseId);
  };

  const handleLeaderboardPress = (
    row: LxpClassReport["leaderboard"][number],
  ) => {
    const caseId = queueCaseByStudent.get(row.studentId);
    if (!caseId) {
      Alert.alert(
        "No active case",
        `${personName(row.student)} has no active intervention case to open.`,
      );
      return;
    }
    openCaseWorkspace(caseId);
  };

  return (
    <TeacherScreen
      title="Interventions"
      subtitle={
        selectedClass
          ? `${selectedClass.subjectCode} | ${selectedClass.subjectName}`
          : "Targeted intervention queue, outcomes, history, and AI-assisted remedial planning."
      }
      icon="account-alert-outline"
      onBackPress={() => navigation.goBack()}
      refreshing={isRefreshing}
      onRefresh={() => void refreshAll()}
    >
      <TeacherSelectMenu
        label="Class"
        selectedValue={selectedClassId}
        options={(classesQuery.data ?? []).map((classItem) => ({
          value: classItem.id,
          label: `${classItem.subjectCode} · ${classItem.subjectName}`,
        }))}
        onSelect={(classId) => {
          setSelectedClassId(classId);
          setSelectedCaseId(null);
          setSelectedHistoryRow(null);
        }}
      />
      <TeacherSegmentedTabs
        accessibilityLabel="Intervention views"
        activeKey={workspaceView}
        items={[
          { key: "queue", label: "Priority", count: visibleQueue.length },
          { key: "overview", label: "Active", count: report?.summary.activeCases ?? 0 },
          { key: "history", label: "History", count: visibleHistory.length },
        ]}
        onSelect={setWorkspaceView}
      />
      <TeacherSummaryStrip
        items={[
          { label: "Pending", value: pendingQuery.data?.pendingCount ?? 0, tone: "amber" },
          { label: "Completed", value: report?.summary.completedCases ?? 0, tone: "green" },
          {
            label: "Avg delta",
            value: report?.summary.averageDelta != null ? `${report.summary.averageDelta.toFixed(1)}%` : "--",
            tone: "blue",
          },
        ]}
      />

      <TeacherSearch
        value={search}
        onChangeText={setSearch}
        placeholder="Search student, email, status, or source"
      />
      <TeacherSelectMenu
        label="Case status"
        selectedValue={statusFilter}
        options={(
          ["all", "pending", "active", "completed", "dismissed"] as StatusFilter[]
        ).map((value) => ({
          value,
          label: value === "all" ? "All status" : value[0].toUpperCase() + value.slice(1),
        }))}
        onSelect={setStatusFilter}
      />
      <TeacherSelectMenu
        label="Sort cases"
        selectedValue={sortMode}
        options={[
          { value: "newest", label: "Newest" },
          { value: "risk", label: "Highest risk" },
          { value: "progress", label: "Least progress" },
        ]}
        onSelect={setSortMode}
      />

      {selectedCaseId ? (
        <TeacherFlatSection
          title="Open case workspace"
          subtitle="Filters above remain clickable; this workspace does not use a blocking overlay."
          action={
            <TeacherActionButton
              label="Close"
              icon="close"
              tone="neutral"
              onPress={() => setSelectedCaseId(null)}
            />
          }
        >
          <TeacherInterventionWorkspaceContent
            navigation={navigation}
            caseId={selectedCaseId}
            classId={selectedClassId}
            embedded
            onClose={() => setSelectedCaseId(null)}
            onAssigned={() => {
              setSelectedCaseId(null);
              void refreshAll();
            }}
          />
        </TeacherFlatSection>
      ) : null}

      {selectedHistoryRow ? (
        <TeacherFlatSection
          title="Learners Path Detail"
          subtitle={`${personName(selectedHistoryRow.student)} | ${selectedHistoryRow.status}`}
          action={
            <TeacherActionButton
              label="Close"
              icon="close"
              tone="neutral"
              onPress={() => setSelectedHistoryRow(null)}
            />
          }
        >
          <TeacherRow
            title="Path score"
            subtitle={
              selectedHistoryRow.pathScore
                ? `${formatPercent(selectedHistoryRow.pathScore.scorePercent)} | ${selectedHistoryRow.pathScore.source}`
                : "No submitted path score yet"
            }
          />
          <TeacherRow
            title="Completion"
            subtitle={`${selectedHistoryRow.completion.completedCheckpoints}/${selectedHistoryRow.completion.totalCheckpoints} checkpoints | ${selectedHistoryRow.completion.completionPercent}% complete`}
          />
          {selectedHistoryRow.assignments.length ? (
            selectedHistoryRow.assignments.map((assignment, index) => (
              <TeacherRow
                key={assignment.id || assignment.assignmentId || `${index}`}
                title={
                  assignment.label ||
                  assignment.lesson?.title ||
                  assignment.assessment?.title ||
                  assignment.generatedLesson?.title ||
                  assignment.guidedAssessment?.title ||
                  "Checkpoint"
                }
                subtitle={`${assignment.type || "checkpoint"} | ${assignment.isCompleted ? "completed" : "pending"} | XP ${assignment.xpAwarded ?? 0}`}
              />
            ))
          ) : (
            <TeacherEmpty
              title="No checkpoints"
              subtitle="This history item has no Learners Path checkpoints."
              icon="playlist-remove"
            />
          )}
        </TeacherFlatSection>
      ) : null}

      {workspaceView === "queue" ? (
        <TeacherFlatSection
          title="Priority Intervention Queue"
          subtitle={`${visibleQueue.length} active queue row(s) shown.`}
        >
          {visibleQueue.length ? (
            visibleQueue.map((entry) => {
              const caseId = entry.id || entry.caseId || "";
              return (
                <View
                  key={caseId}
                  style={{
                    borderTopWidth: 1,
                    borderTopColor: teacherTheme.border,
                  }}
                >
                  <TeacherRow
                    title={caseName(entry)}
                    subtitle={`${severityLabel(entry)} | ${entry.status || "pending"} | Trigger ${formatPercent(entry.triggerScore)} vs ${formatPercent(entry.thresholdApplied)} | Current standing ${formatPercent(entry.latestBlendedScore)} | ${entry.completedCheckpoints ?? 0}/${entry.totalCheckpoints ?? 0} checkpoints`}
                  />
                  <View
                    style={{
                      paddingHorizontal: 14,
                      paddingBottom: 14,
                      flexDirection: "row",
                      flexWrap: "wrap",
                      gap: 8,
                    }}
                  >
                    {entry.aiPlanEligible !== false ? (
                      <TeacherActionButton
                        label="AI Plan"
                        icon="robot-outline"
                        tone="green"
                        onPress={() => openCaseWorkspace(caseId)}
                      />
                    ) : null}
                    {entry.status === "pending" ? (
                      <TeacherActionButton
                        label={
                          busyCaseId === caseId ? "Activating..." : "Activate"
                        }
                        icon="play-circle-outline"
                        tone="blue"
                        disabled={busyCaseId === caseId}
                        onPress={() => void runCaseAction(caseId, "activate")}
                      />
                    ) : null}
                    <TeacherActionButton
                      label="Open Workspace"
                      icon="clipboard-text-outline"
                      tone="purple"
                      onPress={() => openCaseWorkspace(caseId)}
                    />
                    <TeacherActionButton
                      label={busyCaseId === caseId ? "Resolving..." : "Resolve"}
                      icon="check-decagram-outline"
                      tone="amber"
                      disabled={busyCaseId === caseId}
                      onPress={() => void runCaseAction(caseId, "resolve")}
                    />
                  </View>
                </View>
              );
            })
          ) : (
            <TeacherEmpty
              title="No intervention cases"
              subtitle="No queue row matches the current filters."
              icon="account-check-outline"
            />
          )}
        </TeacherFlatSection>
      ) : null}

      {workspaceView === "overview" ? (
        <>
          <TeacherFlatSection
            title="Leaderboard"
            subtitle={`Sorted by ${leaderboardScope}.`}
          >
            <TeacherSelectMenu
              label="Leaderboard measure"
              selectedValue={leaderboardScope}
              options={leaderboardOptions.map((option) => ({
                value: option.key,
                label: option.label,
              }))}
              onSelect={setLeaderboardScope}
            />
            {shownLeaderboardRows.length ? (
              shownLeaderboardRows.map((row, index) => {
                const caseId = queueCaseByStudent.get(row.studentId);
                return (
                  <TeacherRow
                    key={`${row.studentId}-${leaderboardScope}`}
                    title={`#${index + 1} ${personName(row.student)}`}
                    subtitle={`${labelForLeaderboard(row, leaderboardScope)} | ${row.starsTotal} stars | ${caseId ? "Active intervention case" : "No active case"} | ${row.lastActivityAt ? formatDate(row.lastActivityAt) : "No activity yet"}`}
                    onPress={() => handleLeaderboardPress(row)}
                  />
                );
              })
            ) : (
              <TeacherEmpty
                title="No leaderboard records"
                subtitle="Leaderboard appears after students complete LXP checkpoints."
                icon="trophy-outline"
              />
            )}
            {leaderboardRows.length > 5 ? (
              <View style={{ paddingHorizontal: 14, paddingBottom: 14 }}>
                <TeacherActionButton
                  label={
                    leaderboardExpanded ? "Show top 5" : "Show more movers"
                  }
                  icon="format-list-numbered"
                  tone="neutral"
                  onPress={() => setLeaderboardExpanded((current) => !current)}
                />
              </View>
            ) : null}
          </TeacherFlatSection>

          <TeacherFlatSection
            title="Intervention Outcomes"
            subtitle={`${visibleOutcomes.length} outcome row(s) shown.`}
          >
            {visibleOutcomes.length ? (
              visibleOutcomes.map((row) => (
                <TeacherRow
                  key={row.id}
                  title={personName(row.student)}
                  subtitle={`${row.status} | Baseline ${formatPercent(row.triggerScore)} | Current ${formatPercent(row.currentBlendedScore)} | Delta ${row.improvementDelta != null ? `${row.improvementDelta > 0 ? "+" : ""}${row.improvementDelta.toFixed(1)}%` : "--"}`}
                />
              ))
            ) : (
              <TeacherEmpty
                title="No outcomes"
                subtitle="No intervention outcome rows match the current filters."
                icon="chart-line"
              />
            )}
          </TeacherFlatSection>
        </>
      ) : null}

      {workspaceView === "history" ? (
        <TeacherFlatSection
          title="Intervention History"
          subtitle={`Below ${historyQuery.data?.scoreThreshold ?? 60}% can regenerate. ${visibleHistory.length} row(s) shown.`}
        >
          {visibleHistory.length ? (
            visibleHistory.map((row) => (
              <View
                key={row.id}
                style={{
                  borderTopWidth: 1,
                  borderTopColor: teacherTheme.border,
                }}
              >
                <TeacherRow
                  title={personName(row.student)}
                  subtitle={`${row.status} | Path score ${row.pathScore ? formatPercent(row.pathScore.scorePercent) : "--"} | ${row.completion.completedCheckpoints}/${row.completion.totalCheckpoints} checkpoints | Opened ${formatDate(row.openedAt)} | Closed ${formatDate(row.closedAt)}`}
                />
                <View
                  style={{
                    paddingHorizontal: 14,
                    paddingBottom: 14,
                    flexDirection: "row",
                    flexWrap: "wrap",
                    gap: 8,
                  }}
                >
                  <TeacherActionButton
                    label="View Path"
                    icon="playlist-check"
                    tone="blue"
                    onPress={() => {
                      setSelectedCaseId(null);
                      setSelectedHistoryRow(row);
                    }}
                  />
                  {row.canRegenerate ? (
                    <TeacherActionButton
                      label={
                        busyCaseId === row.id
                          ? "Regenerating..."
                          : "Regenerate Path"
                      }
                      icon="refresh"
                      tone="green"
                      disabled={busyCaseId === row.id}
                      onPress={() => void runCaseAction(row.id, "regenerate")}
                    />
                  ) : null}
                </View>
              </View>
            ))
          ) : (
            <TeacherEmpty
              title="No history"
              subtitle="Completed intervention cycles will appear here."
              icon="history"
            />
          )}
        </TeacherFlatSection>
      ) : null}
    </TeacherScreen>
  );
}
