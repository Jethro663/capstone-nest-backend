import { mobileBrand } from "../../theme/mobileBrand";
import { Pressable, ScrollView, Text, TextInput, View } from "react-native";
import { AppAlert as Alert } from "../ui/AppAlert";
import { useEffect, useState } from "react";
import type {
  SpreadsheetCategory,
  SpreadsheetData,
  SpreadsheetStudentRow,
} from "../../types/class-record";
import {
  TeacherActionButton,
  TeacherEmpty,
  TeacherPanel,
  teacherTheme as theme,
} from "./TeacherMobilePrimitives";
import { toAppError } from "../../api/http";

type Props = {
  hideExport?: boolean;
  workbook?: SpreadsheetData | null;
  students?: SpreadsheetStudentRow[];
};

type LearnerFilter = "current" | "historical" | "all";

type SheetColumn = {
  key: string;
  label: string;
  width: number;
  getValue: (student: SpreadsheetStudentRow) => string;
  tone?: "default" | "score" | "summary" | "warning";
};

function formatNumber(value: number | null | undefined, digits = 1) {
  if (typeof value !== "number" || Number.isNaN(value)) return "--";
  return value.toFixed(digits);
}

function getStudentName(student: SpreadsheetStudentRow) {
  return (
    [student.lastName, student.firstName].filter(Boolean).join(", ").trim() ||
    "Learner"
  );
}

function buildCategoryColumns(
  category: SpreadsheetCategory,
  categoryIndex: number,
): SheetColumn[] {
  const itemColumns = category.items.map((item, itemIndex) => ({
    key: `${category.id}:${item.id}`,
    label: `${item.title || `Item ${itemIndex + 1}`}\nHPS ${item.hps ?? "--"}`,
    width: 82,
    tone: "score" as const,
    getValue: (student: SpreadsheetStudentRow) => {
      const categoryScores = student.categories.find(
        (entry) => entry.categoryId === category.id,
      );
      const score = categoryScores?.scores?.[itemIndex];
      const status = categoryScores?.scoreStatuses?.[itemIndex];
      return status === "excused"
        ? "Excused"
        : status === "excused_with_score" && typeof score === "number"
          ? `Excused · ${formatNumber(score, 1)}/${item.hps ?? "--"}`
          : typeof score === "number"
            ? formatNumber(score, 1)
            : "Missing";
    },
  }));

  return [
    ...itemColumns,
    {
      key: `${category.id}:total`,
      label: `${category.name}\nTotal`,
      width: 78,
      tone: "summary",
      getValue: (student) => {
        const categoryScores = student.categories.find(
          (entry) => entry.categoryId === category.id,
        );
        return formatNumber(categoryScores?.total, 1);
      },
    },
    {
      key: `${category.id}:ps`,
      label: `${category.name}\nPS`,
      width: 72,
      tone: "summary",
      getValue: (student) => {
        const categoryScores = student.categories.find(
          (entry) => entry.categoryId === category.id,
        );
        return formatNumber(categoryScores?.ps, 1);
      },
    },
    {
      key: `${category.id}:ws`,
      label: `${category.weight || 0}%\nWS`,
      width: 72,
      tone: "summary",
      getValue: (student) => {
        const categoryScores = student.categories.find(
          (entry) => entry.categoryId === category.id,
        );
        return formatNumber(categoryScores?.ws, 1);
      },
    },
    {
      key: `${category.id}:divider:${categoryIndex}`,
      label: "",
      width: 8,
      getValue: () => "",
    },
  ];
}

function buildColumns(workbook: SpreadsheetData): SheetColumn[] {
  return [
    {
      key: "lrn",
      label: "LRN",
      width: 104,
      getValue: (student) => student.lrn || "--",
    },
    {
      key: "learner",
      label: "Learner Name",
      width: 170,
      getValue: getStudentName,
    },
    ...workbook.categories.flatMap(buildCategoryColumns),
    {
      key: "initial-grade",
      label: "Initial\nGrade",
      width: 88,
      tone: "summary",
      getValue: (student) => formatNumber(student.initialGrade, 2),
    },
    {
      key: "quarterly-grade",
      label: `${workbook.header.periodLabel ?? workbook.header.quarter}\nGrade`,
      width: 92,
      tone: "summary",
      getValue: (student) => formatNumber(student.quarterlyGrade, 0),
    },
    {
      key: "remarks",
      label: "Remarks",
      width: 132,
      tone: "warning",
      getValue: (student) =>
        `${student.gradeProvenance === "legacy_unverified" ? "Legacy unverified: " : student.provisional ? "Provisional: " : ""}${student.remarks || "Incomplete"}`,
    },
  ];
}

function getCellTextColor(column: SheetColumn, value: string) {
  if (column.key === "quarterly-grade") {
    const numeric = Number(value);
    if (!Number.isNaN(numeric) && numeric < 75) return theme.amber;
    return theme.green;
  }
  if (column.tone === "warning" && value.toLowerCase().includes("intervention"))
    return theme.amber;
  if (column.tone === "summary") return theme.red;
  return theme.text;
}

export function MobileClassRecordWorkbook({
  workbook,
  students,
  hideExport = false,
}: Props) {
  const [learnerFilter, setLearnerFilter] = useState<LearnerFilter>(() =>
    workbook?.classRecord.status === "draft" ? "current" : "all",
  );
  const [learnerQuery, setLearnerQuery] = useState("");
  useEffect(() => {
    setLearnerFilter(
      workbook?.classRecord.status === "draft" ? "current" : "all",
    );
    setLearnerQuery("");
  }, [workbook?.classRecord.id, workbook?.classRecord.status]);

  const allRows = students ?? workbook?.students ?? [];
  const rows = allRows.filter((student) => {
    const historical =
      student.isRemoved === true || student.enrollmentState === "removed";
    if (learnerFilter === "current" && historical) return false;
    if (learnerFilter === "historical" && !historical) return false;

    const query = learnerQuery.trim().toLowerCase();
    if (!query) return true;
    return [getStudentName(student), student.lrn, student.studentId].some(
      (value) =>
        String(value ?? "")
          .toLowerCase()
          .includes(query),
    );
  });

  if (!workbook) {
    return (
      <TeacherPanel
        title="Class Record Workbook"
        subtitle="The spreadsheet view will appear after a record is selected."
      >
        <TeacherEmpty
          title="No workbook loaded"
          subtitle="Select or create a class record, then refresh to load the full grade sheet."
          icon="file-table-outline"
        />
      </TeacherPanel>
    );
  }

  const columns = buildColumns(workbook);
  const sheetWidth = columns.reduce((total, column) => total + column.width, 0);

  const handleExportWorkbook = async () => {
    try {
      const { classRecordApi } =
        await import("../../api/services/class-record");
      const { exportAcademicCsv } =
        await import("../../lib/academic-workbook-export");
      const annual = await classRecordApi.annualSummary(
        workbook.classRecord.classId,
      );
      await exportAcademicCsv(workbook, annual);
      Alert.alert(
        "Workbook exported",
        "Includes period and annual evidence, policy, score statuses and source identifiers.",
      );
    } catch (err) {
      Alert.alert("Export Failed", toAppError(err).message);
    }
  };

  return (
    <TeacherPanel
      title="Class Record Workbook"
      subtitle="Swipe sideways to inspect item scores, percentage scores, weighted scores, and policy grades and evidence status."
      action={
        hideExport ? undefined : (
          <TeacherActionButton
            label="Export Workbook"
            icon="file-download-outline"
            tone="green"
            onPress={() => void handleExportWorkbook()}
          />
        )
      }
    >
      <View style={{ paddingHorizontal: 14, paddingBottom: 8 }}>
        <View
          style={{
            borderRadius: 18,
            borderWidth: 1,
            borderColor: theme.border,
            backgroundColor: mobileBrand.navy,
            padding: 12,
          }}
        >
          <Text
            style={{
              fontSize: 11,
              fontWeight: "900",
              letterSpacing: 1,
              textTransform: "uppercase",
              color: mobileBrand.info,
            }}
          >
            {workbook.header.workbookSheetName || workbook.header.quarter}
          </Text>
          <Text
            style={{
              marginTop: 4,
              fontSize: 17,
              fontWeight: "900",
              color: theme.text,
            }}
          >
            {workbook.header.workbookTitle || "DepEd Class Record"}
          </Text>
          <Text
            style={{
              marginTop: 4,
              fontSize: 12,
              lineHeight: 18,
              color: theme.subtext,
            }}
          >
            {workbook.header.subject ||
              workbook.header.subjectCode ||
              "Subject"}{" "}
            | {workbook.header.section || "Section"}
          </Text>
        </View>
      </View>

      <View style={{ paddingHorizontal: 14, paddingBottom: 10 }}>
        <TextInput
          accessibilityLabel="Search class record learners"
          value={learnerQuery}
          onChangeText={setLearnerQuery}
          placeholder="Search learner name or LRN"
          placeholderTextColor={theme.subtext}
          autoCapitalize="none"
          autoCorrect={false}
          style={{
            minHeight: 44,
            borderRadius: 14,
            borderWidth: 1,
            borderColor: theme.border,
            backgroundColor: mobileBrand.white,
            paddingHorizontal: 14,
            color: theme.text,
            fontSize: 14,
            fontWeight: "600",
          }}
        />
      </View>

      <View
        style={{
          flexDirection: "row",
          flexWrap: "wrap",
          gap: 8,
          paddingHorizontal: 14,
          paddingBottom: 10,
        }}
      >
        {(
          [
            ["current", "Current"],
            ["historical", "Historical"],
            ["all", "All"],
          ] as const
        ).map(([value, label]) => (
          <Pressable
            key={value}
            accessibilityRole="button"
            accessibilityLabel={`Show ${value} learners`}
            accessibilityState={{ selected: learnerFilter === value }}
            onPress={() => setLearnerFilter(value)}
            style={{
              borderRadius: 999,
              borderWidth: 1,
              borderColor: learnerFilter === value ? theme.red : theme.border,
              backgroundColor:
                learnerFilter === value
                  ? mobileBrand.redSoft
                  : mobileBrand.white,
              paddingHorizontal: 12,
              paddingVertical: 7,
            }}
          >
            <Text
              style={{
                color: learnerFilter === value ? theme.red : theme.subtext,
                fontSize: 12,
                fontWeight: "800",
              }}
            >
              {label}
            </Text>
          </Pressable>
        ))}
      </View>

      {rows.length ? (
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator
          style={{ marginHorizontal: 14, marginBottom: 14 }}
        >
          <View
            style={{
              width: sheetWidth,
              borderWidth: 1,
              borderColor: theme.border,
              borderRadius: 18,
              overflow: "hidden",
            }}
          >
            <View
              style={{
                flexDirection: "row",
                backgroundColor: mobileBrand.navy,
              }}
            >
              {columns.map((column) => (
                <View
                  key={column.key}
                  style={{
                    width: column.width,
                    minHeight: 56,
                    justifyContent: "center",
                    borderRightWidth: 1,
                    borderRightColor: mobileBrand.inverseSurface,
                    paddingHorizontal: 8,
                    paddingVertical: 8,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 10,
                      lineHeight: 14,
                      fontWeight: "900",
                      color: mobileBrand.infoSoft,
                    }}
                  >
                    {column.label}
                  </Text>
                </View>
              ))}
            </View>

            {rows.map((student, rowIndex) => (
              <View
                key={student.studentId}
                style={{
                  flexDirection: "row",
                  backgroundColor:
                    rowIndex % 2 === 0
                      ? mobileBrand.white
                      : mobileBrand.infoSoft,
                  borderTopWidth: 1,
                  borderTopColor: mobileBrand.infoSoft,
                }}
              >
                {columns.map((column) => {
                  const value = column.getValue(student);
                  const archivedLearner =
                    column.key === "learner" &&
                    student.accountState === "archived";
                  return (
                    <View
                      key={`${student.studentId}:${column.key}`}
                      style={{
                        width: column.width,
                        minHeight: 46,
                        justifyContent: "center",
                        borderRightWidth: 1,
                        borderRightColor: mobileBrand.infoSoft,
                        paddingHorizontal: 8,
                        paddingVertical: 6,
                      }}
                    >
                      {archivedLearner ? (
                        <>
                          <Text
                            numberOfLines={2}
                            accessibilityLabel={`${value}, archived account`}
                            style={{
                              fontSize: 11,
                              lineHeight: 15,
                              fontWeight: "700",
                              color: theme.subtext,
                              textDecorationLine: "line-through",
                            }}
                          >
                            {value}
                          </Text>
                          <Text
                            style={{
                              marginTop: 2,
                              fontSize: 9,
                              lineHeight: 12,
                              fontWeight: "900",
                              color: theme.red,
                            }}
                          >
                            Archived account
                          </Text>
                        </>
                      ) : (
                        <Text
                          numberOfLines={2}
                          style={{
                            fontSize: column.key === "learner" ? 11 : 10,
                            lineHeight: 15,
                            fontWeight:
                              column.tone === "summary" ||
                              column.tone === "warning"
                                ? "900"
                                : "700",
                            color: getCellTextColor(column, value),
                          }}
                        >
                          {value}
                        </Text>
                      )}
                    </View>
                  );
                })}
              </View>
            ))}
          </View>
        </ScrollView>
      ) : (
        <TeacherEmpty
          title={
            learnerQuery.trim()
              ? "No matching learners"
              : "No learners in this workbook"
          }
          subtitle={
            learnerQuery.trim()
              ? "Try another name or LRN, or change the learner filter."
              : "Students and computed grades will appear here after scores are synced."
          }
          icon="account-school-outline"
        />
      )}
    </TeacherPanel>
  );
}
