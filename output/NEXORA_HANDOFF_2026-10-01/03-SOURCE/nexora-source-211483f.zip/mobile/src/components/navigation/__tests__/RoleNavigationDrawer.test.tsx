// @ts-nocheck
import React from "react";
import TestRenderer, { act } from "react-test-renderer";
import {
  ROLE_DRAWER_GROUPS,
  ROLE_DRAWER_PROFILE_DESTINATION,
  flattenRoleDrawerDestinations,
} from "../../../navigation/role-drawer-model";
import { teacherDrawerRouteNames } from "../../../navigation/teacher-route-manifest";
import {
  RoleHeaderNavigationButton,
  RoleDrawerProvider,
  RoleMenuButton,
} from "../RoleNavigationDrawer";
import { mobileBrand } from "../../../theme/mobileBrand";

const mockLogout = jest.fn().mockResolvedValue(undefined);

(globalThis as Record<string, unknown>).IS_REACT_ACT_ENVIRONMENT = true;

jest.mock("react-native", () => {
  const ReactRuntime = require("react") as typeof React;
  const component = (name: string) =>
    function MockComponent(props: Record<string, unknown>) {
      return ReactRuntime.createElement(name, props, props.children);
    };

  return {
    Alert: { alert: jest.fn() },
    Image: component("Image"),
    Modal: ({ visible, children, ...props }: Record<string, unknown>) =>
      visible ? ReactRuntime.createElement("Modal", props, children) : null,
    Pressable: component("Pressable"),
    ScrollView: component("ScrollView"),
    Text: component("Text"),
    View: component("View"),
    useWindowDimensions: () => ({ width: 400, height: 840 }),
  };
});

jest.mock("@expo/vector-icons", () => {
  const ReactRuntime = require("react") as typeof React;
  return {
    MaterialCommunityIcons: (props: Record<string, unknown>) =>
      ReactRuntime.createElement("MaterialCommunityIcons", props),
  };
});

jest.mock("react-native-safe-area-context", () => ({
  useSafeAreaInsets: () => ({ top: 24, right: 0, bottom: 20, left: 0 }),
}));

let consoleErrorSpy: jest.SpyInstance;

beforeAll(() => {
  const originalConsoleError = console.error;
  consoleErrorSpy = jest
    .spyOn(console, "error")
    .mockImplementation((...args: unknown[]) => {
      if (
        typeof args[0] === "string" &&
        args[0].includes("react-test-renderer is deprecated")
      )
        return;
      originalConsoleError(...(args as Parameters<typeof console.error>));
    });
});

afterAll(() => {
  consoleErrorSpy.mockRestore();
});

describe("role drawer destination contracts", () => {
  it("groups every approved teacher destination without the redundant More route", () => {
    expect(ROLE_DRAWER_GROUPS.teacher.map((group) => group.label)).toEqual([
      "Teaching",
      "Content & records",
      "Insights & support",
    ]);
    expect(
      flattenRoleDrawerDestinations("teacher").map((item) => item.label),
    ).toEqual([
      "Home",
      "My Classes",
      "My Sections",
      "Assessments",
      "Calendar",
      "Lessons",
      "Nexora Library",
      "Class Record",
      "Announcements",
      "Reports",
      "Interventions",
      "Performance",
      "Evaluations",
    ]);
    expect(
      flattenRoleDrawerDestinations("teacher").some(
        (item) => item.route === "TeacherMore",
      ),
    ).toBe(false);
    expect(
      flattenRoleDrawerDestinations("teacher").every(
        (item) => item.kind === "tab",
      ),
    ).toBe(true);
  });

  it("categorizes the complete student workspace and exposes evaluations exactly once", () => {
    expect(ROLE_DRAWER_GROUPS.student.map((group) => group.label)).toEqual([
      "Learning",
      "School life",
      "Feedback",
    ]);
    expect(
      flattenRoleDrawerDestinations("student").map((item) => item.route),
    ).toEqual([
      "Dashboard",
      "Classes",
      "Assessments",
      "StudentCalendar",
      "JA",
      "Announcements",
      "StudentEvaluations",
    ]);
    expect(
      flattenRoleDrawerDestinations("student").filter(
        (item) => item.route === "StudentEvaluations",
      ),
    ).toHaveLength(1);
  });

  it("exposes the complete grouped admin workspace", () => {
    expect(ROLE_DRAWER_GROUPS.admin.map((group) => group.label)).toEqual([
      "Overview",
      "School Setup",
      "Content & Comms",
      "Insights & AI",
      "Account",
    ]);
    expect(
      flattenRoleDrawerDestinations("admin").map((item) => item.route),
    ).toEqual([
      "Home",
      "AdminDiagnostics",
      "AdminUsers",
      "AdminSections",
      "AdminClasses",
      "AdminCalendar",
      "AdminRoster",
      "AdminClassRecord",
      "AdminUserReports",
      "AdminLibrary",
      "AdminAnnouncements",
      "AdminReports",
      "AdminEvaluations",
      "AdminChatbot",
      "AdminAudit",
      "AdminSettings",
    ]);
    expect(
      flattenRoleDrawerDestinations("admin").every(
        (item) => item.kind === "tab",
      ),
    ).toBe(true);
    expect(ROLE_DRAWER_PROFILE_DESTINATION).toMatchObject({
      label: "Profile",
      route: "Profile",
      kind: "tab",
    });
  });

  it("keeps the teacher navigator in the exact order shown by the drawer", () => {
    expect([
      ...flattenRoleDrawerDestinations("teacher").map((item) => item.route),
      ROLE_DRAWER_PROFILE_DESTINATION.route,
    ]).toEqual(teacherDrawerRouteNames);
  });
});

describe("RoleDrawerProvider", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("opens from a 48px hamburger, renders an 84% drawer, navigates, and closes", () => {
    const onNavigate = jest.fn();
    let renderer: TestRenderer.ReactTestRenderer;

    act(() => {
      renderer = TestRenderer.create(
        <RoleDrawerProvider
          role="teacher"
          activeRouteName="Home"
          onNavigate={onNavigate}
        >
          <RoleMenuButton />
        </RoleDrawerProvider>,
      );
    });

    const trigger = renderer!.root.findByProps({
      accessibilityLabel: "Open navigation menu",
    });
    const triggerControl = trigger.findByType("Pressable");
    expect(triggerControl.props.style).toMatchObject({
      minWidth: mobileBrand.minTarget,
      minHeight: mobileBrand.minTarget,
      backgroundColor: mobileBrand.inverseSurface,
      borderColor: mobileBrand.inverseBorder,
    });
    expect(renderer!.root.findByProps({ name: "menu" }).props.color).toBe(
      mobileBrand.inverseForeground,
    );

    act(() => trigger.props.onPress());

    const drawer = renderer!.root.findByProps({
      testID: "role-navigation-drawer",
    });
    expect(drawer.props.style.width).toBe(336);
    expect(
      renderer!.root.findByProps({
        accessibilityLabel: "Close navigation menu",
      }),
    ).toBeTruthy();

    const classes = renderer!.root.findByProps({
      accessibilityLabel: "Go to My Classes",
    });
    act(() => classes.props.onPress());

    expect(onNavigate).toHaveBeenCalledWith(
      expect.objectContaining({
        label: "My Classes",
        route: "Classes",
        kind: "tab",
      }),
    );
    expect(
      renderer!.root.findAllByProps({ testID: "role-navigation-drawer" }),
    ).toHaveLength(0);
  });

  it("falls back to Back outside a root drawer context", () => {
    const onBackPress = jest.fn();
    let renderer: TestRenderer.ReactTestRenderer;

    act(() => {
      renderer = TestRenderer.create(
        <RoleHeaderNavigationButton onBackPress={onBackPress} />,
      );
    });

    const back = renderer!.root.findByProps({ accessibilityLabel: "Back" });
    const backControl = back.findByType("Pressable");
    expect(backControl.props.style).toMatchObject({
      minWidth: mobileBrand.minTarget,
      minHeight: mobileBrand.minTarget,
      backgroundColor: mobileBrand.inverseSurface,
      borderColor: mobileBrand.inverseBorder,
    });
    expect(renderer!.root.findByProps({ name: "arrow-left" }).props.color).toBe(
      mobileBrand.inverseForeground,
    );
    act(() => back.props.onPress());
    expect(onBackPress).toHaveBeenCalledTimes(1);
    expect(
      renderer!.root.findAllByProps({
        accessibilityLabel: "Open navigation menu",
      }),
    ).toHaveLength(0);
  });

  it("prefers the hamburger inside a drawer context even when Back is available", () => {
    const onBackPress = jest.fn();
    let renderer: TestRenderer.ReactTestRenderer;

    act(() => {
      renderer = TestRenderer.create(
        <RoleDrawerProvider
          role="teacher"
          activeRouteName="TeacherCalendar"
          onNavigate={jest.fn()}
        >
          <RoleHeaderNavigationButton onBackPress={onBackPress} />
        </RoleDrawerProvider>,
      );
    });

    const menu = renderer!.root.findByProps({
      accessibilityLabel: "Open navigation menu",
    });
    act(() => menu.props.onPress());

    expect(
      renderer!.root.findByProps({ testID: "role-navigation-drawer" }),
    ).toBeTruthy();
    expect(
      renderer!.root.findAllByProps({ accessibilityLabel: "Back" }),
    ).toHaveLength(0);
    expect(onBackPress).not.toHaveBeenCalled();
  });

  it("puts Profile beside a confirmed Log out action in student and teacher drawers", async () => {
    const { Alert } = require("react-native") as {
      Alert: { alert: jest.Mock };
    };
    let studentRenderer: TestRenderer.ReactTestRenderer;

    act(() => {
      studentRenderer = TestRenderer.create(
        <RoleDrawerProvider
          role="student"
          activeRouteName="Dashboard"
          onNavigate={jest.fn()}
          onLogout={mockLogout}
        >
          <RoleMenuButton />
        </RoleDrawerProvider>,
      );
    });
    act(() =>
      studentRenderer!.root
        .findByProps({ accessibilityLabel: "Open navigation menu" })
        .props.onPress(),
    );

    const footer = studentRenderer!.root.findByProps({
      testID: "student-drawer-footer",
    });
    expect(footer.props.style).toMatchObject({ flexDirection: "row" });
    expect(
      studentRenderer!.root.findByProps({
        accessibilityLabel: "Go to Profile",
      }),
    ).toBeTruthy();

    act(() =>
      studentRenderer!.root
        .findByProps({ accessibilityLabel: "Log out" })
        .props.onPress(),
    );
    expect(Alert.alert).toHaveBeenCalledWith(
      "Log out?",
      "You will need to sign in again to continue learning.",
      expect.any(Array),
    );

    const actions = Alert.alert.mock.calls.at(-1)?.[2] as Array<{
      text: string;
      onPress?: () => Promise<void>;
    }>;
    await act(async () => {
      await actions.find((button) => button.text === "Log out")?.onPress?.();
    });
    expect(mockLogout).toHaveBeenCalledTimes(1);

    let teacherRenderer: TestRenderer.ReactTestRenderer;
    act(() => {
      teacherRenderer = TestRenderer.create(
        <RoleDrawerProvider
          role="teacher"
          activeRouteName="Home"
          onNavigate={jest.fn()}
          onLogout={mockLogout}
        >
          <RoleMenuButton />
        </RoleDrawerProvider>,
      );
    });
    act(() =>
      teacherRenderer!.root
        .findByProps({ accessibilityLabel: "Open navigation menu" })
        .props.onPress(),
    );
    expect(
      teacherRenderer!.root.findByProps({ testID: "teacher-drawer-footer" }),
    ).toBeTruthy();
    expect(
      teacherRenderer!.root.findByProps({ accessibilityLabel: "Log out" }),
    ).toBeTruthy();
  });

  it("uses the platform alert outside test mode so drawer logout does not stack app modals", () => {
    const previousNodeEnv = process.env.NODE_ENV;
    process.env.NODE_ENV = "development";
    const { Alert } = require("react-native") as {
      Alert: { alert: jest.Mock };
    };
    let renderer: TestRenderer.ReactTestRenderer;

    try {
      act(() => {
        renderer = TestRenderer.create(
          <RoleDrawerProvider
            role="student"
            activeRouteName="Dashboard"
            onNavigate={jest.fn()}
            onLogout={mockLogout}
          >
            <RoleMenuButton />
          </RoleDrawerProvider>,
        );
      });
      act(() =>
        renderer!.root
          .findByProps({ accessibilityLabel: "Open navigation menu" })
          .props.onPress(),
      );
      act(() =>
        renderer!.root
          .findByProps({ accessibilityLabel: "Log out" })
          .props.onPress(),
      );

      expect(Alert.alert).toHaveBeenCalledWith(
        "Log out?",
        "You will need to sign in again to continue learning.",
        expect.any(Array),
      );
    } finally {
      process.env.NODE_ENV = previousNodeEnv;
    }
  });
});
