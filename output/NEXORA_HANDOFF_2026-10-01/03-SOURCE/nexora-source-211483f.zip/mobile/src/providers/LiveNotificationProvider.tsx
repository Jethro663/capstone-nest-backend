import { mobileBrand } from "../theme/mobileBrand";
import type { PropsWithChildren } from "react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import * as Notifications from "expo-notifications";
import { io, type Socket } from "socket.io-client";
import { Animated, AppState, Easing, Platform, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { getAccessToken } from "../api/client";
import { SOCKET_ORIGIN } from "../api/config";
import { assessmentsApi } from "../api/services/assessments";
import { classesApi } from "../api/services/classes";
import { lxpApi } from "../api/services/lxp";
import { notificationsApi } from "../api/services/notifications";
import { QuietNotificationBanner } from "../components/notifications/QuietNotificationBanner";
import { rootNavigationRef } from "../navigation/navigation-ref";
import { resolveMobileRole } from "../navigation/role-resolver";
import type { Assessment, AssessmentAttempt } from "../types/assessment";
import type { ClassItem } from "../types/class";
import type { LxpPathSummary } from "../types/lxp";
import type { MobileNotification } from "../types/notification";
import { resolveMobileNotificationAction } from "../utils/mobile-notification-routing";
import {
  addQuietNotifications,
  dismissQuietNotifications,
  EMPTY_QUIET_NOTIFICATION_PRESENTATION,
} from "../utils/quiet-notification-presentation";
import { useAuth } from "./AuthProvider";
import { LiveNotificationContext } from "./LiveNotificationContext";
import { syncCurrentPushRegistration } from "../services/notifications/push-registration.runtime";

const AT_RISK_TERMS = ["at risk", "at-risk", "flagged"];
const INTERVENTION_ALERT_TERMS = ["intervention", "support plan"];
const BLUE_REMINDER_TYPES = new Set([
  "student_pending_task_reminder",
  "student_pending_intervention_reminder",
]);
const BLUE_INTERVENTION_TERMS = [
  "checklist",
  "learner path",
  "learners path",
  "assigned path",
  "pending intervention",
];
const ASSESSMENT_TYPES = new Set([
  "assessment_assigned",
  "assessment_due",
  "assessment_graded",
  "student_pending_task_reminder",
]);
const NOTIFICATION_POLL_MS = 10_000;
const STUDENT_REMINDER_POLL_MS = 90_000;
const TEACHER_REMINDER_POLL_MS = 90_000;
const LOCAL_REMINDER_BUCKET_MS = 5 * 60 * 1000;
const STUDENT_REMINDER_CLASS_LIMIT = 6;
const STUDENT_REMINDER_ASSESSMENT_LIMIT = 16;
const AUTO_DISMISS_MS = 6000;
const NATIVE_NOTIFICATION_CHANNEL_ID = "nexora-live";
const NATIVE_NOTIFICATION_PREFIX = "nexora-notification";
const NOTIFICATION_TAP_RETRY_MS = 320;
const PUSH_REGISTRATION_RETRY_MS = 30_000;

try {
  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldPlaySound: true,
      shouldSetBadge: true,
      shouldShowBanner: true,
      shouldShowList: true,
      priority: Notifications.AndroidNotificationPriority.HIGH,
    }),
  });
} catch {
  // Expo notifications can be unavailable in lightweight test/runtime shells.
}

function normalizeText(value: unknown) {
  if (value === null || value === undefined) return "";
  return String(value).trim().toLowerCase();
}

function messageFromNotification(
  notification: Pick<MobileNotification, "message" | "body">,
) {
  const message = notification.message?.trim();
  if (message) return message;
  return notification.body?.trim() || "A new update is available.";
}

function readPayloadString(value: unknown) {
  return typeof value === "string" ? value : "";
}

function notificationToNativeData(
  notification: MobileNotification,
  role: string | null,
) {
  return {
    source: NATIVE_NOTIFICATION_PREFIX,
    notificationId: notification.id,
    userId: notification.userId,
    type: notification.type,
    title: notification.title,
    body: notification.body || "",
    message: messageFromNotification(notification),
    referenceId: notification.referenceId || "",
    classId: notification.metadata?.classId || "",
    createdAt: notification.createdAt,
    role: role || "",
  };
}

function notificationFromNativeData(
  data: Record<string, unknown> | undefined,
): MobileNotification | null {
  if (!data || data.source !== NATIVE_NOTIFICATION_PREFIX) return null;

  const id =
    readPayloadString(data.notificationId) || readPayloadString(data.id);
  const title = readPayloadString(data.title);
  const type = readPayloadString(data.type);

  if (!id || !title || !type) return null;

  return {
    id,
    userId: readPayloadString(data.userId),
    type,
    title,
    body: readPayloadString(data.body),
    message: readPayloadString(data.message),
    isRead: false,
    referenceId: readPayloadString(data.referenceId) || null,
    metadata: readPayloadString(data.classId)
      ? { classId: readPayloadString(data.classId) }
      : null,
    createdAt: readPayloadString(data.createdAt) || new Date().toISOString(),
  };
}

type RealtimeNotificationPayload = {
  id?: unknown;
  type?: unknown;
  title?: unknown;
  body?: unknown;
  message?: unknown;
  referenceId?: unknown;
  metadata?: unknown;
  createdAt?: unknown;
};

function getNotificationSeenKeys(
  notification: Pick<MobileNotification, "id" | "type" | "referenceId">,
) {
  return notification.id ? [notification.id] : [];
}

function hasSeenNotification(
  seen: Set<string>,
  notification: Pick<MobileNotification, "id" | "type" | "referenceId">,
) {
  return getNotificationSeenKeys(notification).some((key) => seen.has(key));
}

function markNotificationSeen(
  seen: Set<string>,
  notification: Pick<MobileNotification, "id" | "type" | "referenceId">,
) {
  getNotificationSeenKeys(notification).forEach((key) => seen.add(key));
}

function notificationFromRealtimePayload(
  payload: RealtimeNotificationPayload,
  userId: string,
): MobileNotification | null {
  const type = readPayloadString(payload.type);
  const title = readPayloadString(payload.title);
  const referenceId = readPayloadString(payload.referenceId) || null;
  const createdAt =
    readPayloadString(payload.createdAt) || new Date().toISOString();
  const id =
    readPayloadString(payload.id) ||
    `${type}:${referenceId || "broadcast"}:${createdAt}`;
  const metadata =
    payload.metadata &&
    typeof payload.metadata === "object" &&
    !Array.isArray(payload.metadata)
      ? (payload.metadata as Record<string, unknown>)
      : null;

  if (!id || !type || !title) return null;

  const body = readPayloadString(payload.body);
  const message = readPayloadString(payload.message) || body;

  return {
    id,
    userId,
    type,
    title,
    body,
    message,
    isRead: false,
    referenceId,
    metadata,
    createdAt,
  };
}

function isInterventionAlertNotification(
  notification: Pick<MobileNotification, "type" | "title" | "message" | "body">,
) {
  if (BLUE_REMINDER_TYPES.has(notification.type)) return false;

  const joined = normalizeText(
    notification.type +
      " " +
      notification.title +
      " " +
      (notification.message ?? "") +
      " " +
      (notification.body ?? ""),
  );

  if (AT_RISK_TERMS.some((term) => joined.includes(term))) return true;
  if (BLUE_INTERVENTION_TERMS.some((term) => joined.includes(term)))
    return false;
  return INTERVENTION_ALERT_TERMS.some((term) => joined.includes(term));
}

function shouldSurfaceNotificationOnHydration(
  notification: MobileNotification,
) {
  return !notification.isRead;
}

function isLocalReminderId(value: string) {
  return (
    value.startsWith("student-reminder:") ||
    value.startsWith("teacher-reminder:")
  );
}

function isLocalReminderNotification(
  notification: Pick<MobileNotification, "id" | "type">,
) {
  return (
    isLocalReminderId(notification.id) ||
    BLUE_REMINDER_TYPES.has(notification.type)
  );
}

function resolveUserId(user: unknown) {
  const record = user as { id?: unknown; userId?: unknown };
  const id = typeof record.id === "string" ? record.id : "";
  const userId = typeof record.userId === "string" ? record.userId : "";
  return id || userId;
}

function reminderDateKey() {
  const now = new Date();
  const bucket = Math.floor(now.getTime() / LOCAL_REMINDER_BUCKET_MS);
  return `${now.toISOString().slice(0, 10)}:${bucket}`;
}

function getClassLabel(classItem: ClassItem) {
  return (
    classItem.subjectName ||
    classItem.subjectCode ||
    classItem.name ||
    classItem.className ||
    "your class"
  );
}

function getAssessmentDueMs(assessment: Assessment) {
  if (!assessment.dueDate) return Number.MAX_SAFE_INTEGER;
  const dueMs = Date.parse(assessment.dueDate);
  return Number.isFinite(dueMs) ? dueMs : Number.MAX_SAFE_INTEGER;
}

function getLatestAttempt(attempts: AssessmentAttempt[]) {
  return [...attempts].sort((left, right) => {
    const leftTime = Date.parse(
      left.submittedAt || left.startedAt || left.createdAt || "",
    );
    const rightTime = Date.parse(
      right.submittedAt || right.startedAt || right.createdAt || "",
    );
    return (
      (Number.isFinite(rightTime) ? rightTime : 0) -
      (Number.isFinite(leftTime) ? leftTime : 0)
    );
  })[0];
}

async function buildStudentPendingTaskReminder(
  studentId: string,
): Promise<MobileNotification | null> {
  const classRows = await classesApi
    .getStudentClasses(studentId)
    .catch(() => [] as ClassItem[]);
  if (classRows.length === 0) return null;

  const batches = await Promise.all(
    classRows.slice(0, STUDENT_REMINDER_CLASS_LIMIT).map(async (classItem) => {
      const assessments = await assessmentsApi
        .getByClass(classItem.id)
        .catch(() => [] as Assessment[]);
      const published = assessments
        .filter(
          (assessment) => assessment.id && assessment.isPublished !== false,
        )
        .slice(0, STUDENT_REMINDER_ASSESSMENT_LIMIT);

      const statuses = await Promise.all(
        published.map(async (assessment) => {
          const attempts = await assessmentsApi
            .getStudentAttempts(assessment.id)
            .catch(() => [] as AssessmentAttempt[]);
          return {
            assessment,
            classItem,
            latestAttempt: getLatestAttempt(attempts),
            dueMs: getAssessmentDueMs(assessment),
          };
        }),
      );

      return statuses.filter((entry) => !entry.latestAttempt?.isSubmitted);
    }),
  );

  const pending = batches
    .flat()
    .sort(
      (left, right) =>
        left.dueMs - right.dueMs ||
        left.assessment.title.localeCompare(right.assessment.title),
    );

  if (pending.length === 0) return null;

  const first = pending[0];
  const classLabel = getClassLabel(first.classItem);
  const title =
    pending.length === 1
      ? "1 pending task waiting"
      : String(pending.length) + " pending tasks waiting";
  const message =
    pending.length === 1
      ? first.assessment.title +
        " in " +
        classLabel +
        " is ready. Tap to open your assessments."
      : first.assessment.title +
        " is next, plus " +
        String(pending.length - 1) +
        " more task(s). Tap to open your assessments.";

  return {
    id:
      "student-reminder:pending-task:" +
      studentId +
      ":" +
      reminderDateKey() +
      ":" +
      first.assessment.id +
      ":" +
      String(pending.length),
    userId: studentId,
    type: "student_pending_task_reminder",
    title,
    body: message,
    message,
    isRead: true,
    referenceId: first.assessment.id,
    createdAt: new Date().toISOString(),
  };
}

function getPendingPathCount(path: LxpPathSummary) {
  const explicitPending = Number(path.counts?.pending ?? 0);
  if (explicitPending > 0) return explicitPending;

  const total = Number(
    path.progress?.totalCheckpoints ?? path.counts?.total ?? 0,
  );
  const completed = Number(
    path.progress?.completedCheckpoints ?? path.counts?.completed ?? 0,
  );
  return Math.max(0, total - completed);
}

async function buildStudentPendingInterventionReminder(
  studentId: string,
): Promise<MobileNotification | null> {
  const eligibility = await lxpApi.getEligibility().catch(() => null);
  const paths = eligibility?.paths || [];
  const pendingPaths = paths
    .map((path) => ({ path, pendingCount: getPendingPathCount(path) }))
    .filter(
      ({ path, pendingCount }) =>
        path.status !== "completed" && pendingCount > 0,
    );

  if (pendingPaths.length === 0) {
    const alerts = await lxpApi.getInterventionAlerts().catch(() => null);
    const assignedAlerts = (alerts?.alerts || []).filter(
      (alert) => alert.hasAssignedPath,
    );
    if (assignedAlerts.length === 0) return null;

    const firstAlert = assignedAlerts[0];
    const subjectLabel =
      firstAlert.subjectName || firstAlert.subjectCode || "Learners Path";
    const message =
      assignedAlerts.length === 1
        ? subjectLabel +
          " has an intervention path ready. JA can guide you through it now."
        : subjectLabel +
          " is ready, plus " +
          String(assignedAlerts.length - 1) +
          " more intervention path(s). JA can guide you now.";

    return {
      id:
        "student-reminder:pending-intervention:" +
        studentId +
        ":" +
        reminderDateKey() +
        ":" +
        firstAlert.classId +
        ":alerts:" +
        String(assignedAlerts.length),
      userId: studentId,
      type: "student_pending_intervention_reminder",
      title: "Learners Path needs you",
      body: message,
      message,
      isRead: true,
      referenceId: firstAlert.classId,
      createdAt: new Date().toISOString(),
    };
  }

  const first = pendingPaths[0];
  const totalPending = pendingPaths.reduce(
    (sum, item) => sum + item.pendingCount,
    0,
  );
  const subjectLabel =
    first.path.class?.subjectName ||
    first.path.class?.subjectCode ||
    "Learners Path";
  const message =
    totalPending === 1
      ? subjectLabel +
        " has 1 pending intervention step. JA can guide you through it now."
      : subjectLabel +
        " has " +
        String(first.pendingCount) +
        " pending step(s), with " +
        String(totalPending) +
        " total across your intervention paths.";

  return {
    id:
      "student-reminder:pending-intervention:" +
      studentId +
      ":" +
      reminderDateKey() +
      ":" +
      first.path.classId +
      ":" +
      String(totalPending),
    userId: studentId,
    type: "student_pending_intervention_reminder",
    title: "Learners Path needs you",
    body: message,
    message,
    isRead: true,
    referenceId: first.path.classId,
    createdAt: new Date().toISOString(),
  };
}

async function buildTeacherPendingInterventionReminder(
  userId: string,
): Promise<MobileNotification | null> {
  const pending = await lxpApi
    .getTeacherPendingInterventionCount()
    .catch(() => null);
  const pendingCount = Number(pending?.pendingCount ?? 0);
  if (pendingCount <= 0) return null;

  const classBreakdown = (pending?.classBreakdown || []) as Array<{
    classId?: string | null;
    subjectName?: string | null;
    subjectCode?: string | null;
    pendingCount?: number | null;
  }>;
  const firstClass = classBreakdown.find(
    (entry) => Number(entry.pendingCount ?? 0) > 0,
  );
  const classLabel =
    firstClass?.subjectName || firstClass?.subjectCode || "your classes";
  const message =
    pendingCount === 1
      ? classLabel + " has 1 learner waiting for intervention review."
      : classLabel +
        " has intervention work waiting, with " +
        String(pendingCount) +
        " learner(s) needing review.";

  return {
    id:
      "teacher-reminder:pending-interventions:" +
      userId +
      ":" +
      reminderDateKey() +
      ":" +
      (firstClass?.classId || "all") +
      ":" +
      String(pendingCount),
    userId,
    type: "teacher_pending_intervention_reminder",
    title: "Intervention queue needs review",
    body: message,
    message,
    isRead: true,
    referenceId: firstClass?.classId || null,
    createdAt: new Date().toISOString(),
  };
}

function navigateToNotification(
  notification: MobileNotification,
  role: string | null,
) {
  if (!rootNavigationRef.isReady()) return false;
  const action = resolveMobileNotificationAction(notification, role);
  (
    rootNavigationRef.navigate as unknown as (
      name: string,
      params?: unknown,
    ) => void
  )(action.routeName, action.params);
  return true;
}

export function LiveNotificationProvider({ children }: PropsWithChildren) {
  const { isAuthenticated, user } = useAuth();
  const insets = useSafeAreaInsets();
  const [quietPresentation, setQuietPresentation] = useState(
    EMPTY_QUIET_NOTIFICATION_PRESENTATION,
  );
  const [unreadCount, setUnreadCount] = useState(0);

  const seenIdsRef = useRef<Set<string>>(new Set());
  const hydratedRef = useRef(false);
  const mountedRef = useRef(true);
  const pollInFlightRef = useRef(false);
  const pollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const autoDismissTimerRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );
  const nativeReadyRef = useRef(false);
  const nativeDeniedRef = useRef(false);
  const scheduledNativeIdsRef = useRef<Set<string>>(new Set());
  const studentReminderInFlightRef = useRef(false);
  const teacherReminderInFlightRef = useRef(false);
  const pendingNativeOpenRef = useRef<MobileNotification | null>(null);
  const socketRef = useRef<Socket | null>(null);
  const appStateRef = useRef(AppState.currentState);
  const pushRegistrationInFlightRef = useRef(false);
  const pushRegistrationRetryRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );

  const slide = useRef(new Animated.Value(-140)).current;
  const opacity = useRef(new Animated.Value(0)).current;
  const role = resolveMobileRole(user?.roles);

  useEffect(() => {
    return () => {
      mountedRef.current = false;
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
        pollTimerRef.current = null;
      }
      if (autoDismissTimerRef.current) {
        clearTimeout(autoDismissTimerRef.current);
        autoDismissTimerRef.current = null;
      }
      socketRef.current?.disconnect();
      socketRef.current = null;
      if (pushRegistrationRetryRef.current) {
        clearTimeout(pushRegistrationRetryRef.current);
        pushRegistrationRetryRef.current = null;
      }
    };
  }, []);

  const ensureNativeNotificationsReady = useCallback(async () => {
    if (nativeReadyRef.current) return true;
    if (nativeDeniedRef.current) return false;

    try {
      if (Platform.OS === "android") {
        await Notifications.setNotificationChannelAsync(
          NATIVE_NOTIFICATION_CHANNEL_ID,
          {
                name: "Nexora live alerts",
                importance: Notifications.AndroidImportance.HIGH,
                lockscreenVisibility:
                  Notifications.AndroidNotificationVisibility.PRIVATE,
            vibrationPattern: [0, 260, 120, 260],
            lightColor: mobileBrand.danger,
            enableVibrate: true,
            showBadge: true,
          },
        );
      }

      const current = await Notifications.getPermissionsAsync();
      let status = current.status;

      if (status !== "granted" && current.canAskAgain !== false) {
        const requested = await Notifications.requestPermissionsAsync();
        status = requested.status;
      }

      const granted = status === "granted";
      nativeReadyRef.current = granted;
      nativeDeniedRef.current = !granted;
      return granted;
    } catch {
      nativeDeniedRef.current = true;
      return false;
    }
  }, []);

  const syncPushDevice = useCallback(async () => {
    if (pushRegistrationInFlightRef.current) return null;
    pushRegistrationInFlightRef.current = true;
    try {
      return await syncCurrentPushRegistration();
    } finally {
      pushRegistrationInFlightRef.current = false;
    }
  }, []);

  useEffect(() => {
    if (!isAuthenticated || !user?.id) return;
    let active = true;
    const register = async () => {
      const result = await syncPushDevice();
      if (!active || result?.status !== "retryable_error") return;
      pushRegistrationRetryRef.current = setTimeout(() => {
        void register();
      }, PUSH_REGISTRATION_RETRY_MS);
    };
    void register();
    return () => {
      active = false;
      if (pushRegistrationRetryRef.current) {
        clearTimeout(pushRegistrationRetryRef.current);
        pushRegistrationRetryRef.current = null;
      }
    };
  }, [isAuthenticated, syncPushDevice, user?.id]);

  const scheduleNativeNotification = useCallback(
    async (notification: MobileNotification) => {
      if (scheduledNativeIdsRef.current.has(notification.id)) return;

      const ready = await ensureNativeNotificationsReady();
      if (!ready) return;

      scheduledNativeIdsRef.current.add(notification.id);
      const interventionAlert = isInterventionAlertNotification(notification);

      try {
        await Notifications.scheduleNotificationAsync({
          identifier: `${NATIVE_NOTIFICATION_PREFIX}:${notification.id}`,
          content: {
            title: interventionAlert
              ? `JA alert: ${notification.title}`
              : notification.title,
            body: messageFromNotification(notification),
            data: notificationToNativeData(notification, role),
            sound: true,
            priority: Notifications.AndroidNotificationPriority.HIGH,
            color: interventionAlert ? mobileBrand.danger : mobileBrand.info,
            vibrate: interventionAlert ? [0, 280, 120, 280] : [0, 180],
            autoDismiss: true,
          },
          trigger:
            Platform.OS === "android"
              ? { channelId: NATIVE_NOTIFICATION_CHANNEL_ID }
              : null,
        });
      } catch {
        scheduledNativeIdsRef.current.delete(notification.id);
      }
    },
    [ensureNativeNotificationsReady, role],
  );

  const openOrDeferNativeNotification = useCallback(
    (notification: MobileNotification) => {
      if (!isLocalReminderNotification(notification)) {
        setUnreadCount((current) => Math.max(0, current - 1));
        void notificationsApi.markRead(notification.id).catch(() => {
          // Keep the tap path resilient even if the read-state request is interrupted.
        });
      }

      if (navigateToNotification(notification, role)) {
        pendingNativeOpenRef.current = null;
        return;
      }

      pendingNativeOpenRef.current = notification;
      setTimeout(() => {
        const pending = pendingNativeOpenRef.current;
        if (pending && navigateToNotification(pending, role)) {
          pendingNativeOpenRef.current = null;
        }
      }, NOTIFICATION_TAP_RETRY_MS);
    },
    [role],
  );

  const clearLocalReminderSeenKeys = useCallback(() => {
    seenIdsRef.current.forEach((key) => {
      if (isLocalReminderId(key)) {
        seenIdsRef.current.delete(key);
      }
    });
  }, []);

  const enqueueLiveNotification = useCallback(
    (notification: MobileNotification) => {
      if (
        !notification.id ||
        hasSeenNotification(seenIdsRef.current, notification)
      )
        return false;
      markNotificationSeen(seenIdsRef.current, notification);
      setQuietPresentation((current) => addQuietNotifications(current, 1));
      return true;
    },
    [],
  );

  const dismissActive = useCallback(() => {
    if (autoDismissTimerRef.current) {
      clearTimeout(autoDismissTimerRef.current);
      autoDismissTimerRef.current = null;
    }

    setQuietPresentation(dismissQuietNotifications());
    opacity.setValue(0);
    slide.setValue(-12);
  }, [opacity, slide]);

  const openNotificationCenter = useCallback(() => {
    if (!rootNavigationRef.isReady()) return;
    dismissActive();
    setTimeout(() => {
      rootNavigationRef.navigate("Notifications");
    }, 180);
  }, [dismissActive]);

  useEffect(() => {
    if (!quietPresentation.visible) return;

    slide.setValue(-8);
    opacity.setValue(0);

    Animated.parallel([
      Animated.timing(opacity, {
        toValue: 1,
        duration: 160,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
      Animated.timing(slide, {
        toValue: 0,
        duration: 180,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }),
    ]).start();

    autoDismissTimerRef.current = setTimeout(() => {
      dismissActive();
    }, AUTO_DISMISS_MS);

    return () => {
      if (autoDismissTimerRef.current) {
        clearTimeout(autoDismissTimerRef.current);
        autoDismissTimerRef.current = null;
      }
    };
  }, [
    dismissActive,
    opacity,
    quietPresentation.count,
    quietPresentation.visible,
    slide,
  ]);

  const syncStudentReminderNotifications = useCallback(async () => {
    if (
      !isAuthenticated ||
      role !== "student" ||
      studentReminderInFlightRef.current
    )
      return;

    const studentId = resolveUserId(user);
    if (!studentId) return;

    studentReminderInFlightRef.current = true;
    try {
      const [taskReminder, interventionReminder] = await Promise.all([
        buildStudentPendingTaskReminder(studentId).catch(() => null),
        buildStudentPendingInterventionReminder(studentId).catch(() => null),
      ]);

      if (taskReminder) enqueueLiveNotification(taskReminder);
      if (interventionReminder) enqueueLiveNotification(interventionReminder);
    } catch {
      // Local reminders should never interrupt the core notification stream.
    } finally {
      studentReminderInFlightRef.current = false;
    }
  }, [enqueueLiveNotification, isAuthenticated, role, user]);

  const syncTeacherReminderNotifications = useCallback(async () => {
    if (
      !isAuthenticated ||
      role !== "teacher" ||
      teacherReminderInFlightRef.current
    )
      return;

    const teacherId = resolveUserId(user);
    if (!teacherId) return;

    teacherReminderInFlightRef.current = true;
    try {
      const interventionReminder =
        await buildTeacherPendingInterventionReminder(teacherId).catch(
          () => null,
        );
      if (interventionReminder) enqueueLiveNotification(interventionReminder);
    } catch {
      // Teacher reminders should never interrupt the core notification stream.
    } finally {
      teacherReminderInFlightRef.current = false;
    }
  }, [enqueueLiveNotification, isAuthenticated, role, user]);

  const pollNotifications = useCallback(async () => {
    if (!isAuthenticated || !user?.id || pollInFlightRef.current) return;

    pollInFlightRef.current = true;
    try {
      const [listResponse, unread] = await Promise.all([
        notificationsApi.getAll({ limit: 25 }),
        notificationsApi.getUnreadCount(),
      ]);

      if (!mountedRef.current) return;
      const nextUnreadCount = Math.max(0, Number(unread?.count ?? 0));
      setUnreadCount(nextUnreadCount);

      const rows = Array.isArray(listResponse.data) ? listResponse.data : [];
      if (!hydratedRef.current) {
        const unreadRows = rows.filter(shouldSurfaceNotificationOnHydration);
        const hydrationCount = Math.max(nextUnreadCount, unreadRows.length);

        rows.forEach((row) => {
          markNotificationSeen(seenIdsRef.current, row);
        });
        hydratedRef.current = true;
        if (hydrationCount > 0) {
          setQuietPresentation((current) =>
            addQuietNotifications(current, hydrationCount),
          );
        }
        return;
      }

      const fresh = rows.filter(
        (row) => !row.isRead && !hasSeenNotification(seenIdsRef.current, row),
      );
      if (fresh.length === 0) return;

      fresh.forEach((row) => {
        markNotificationSeen(seenIdsRef.current, row);
      });
      setQuietPresentation((current) =>
        addQuietNotifications(current, fresh.length),
      );
    } catch {
      // Keep UI resilient and skip transient notification failures.
    } finally {
      pollInFlightRef.current = false;
    }
  }, [isAuthenticated, user?.id]);

  useEffect(() => {
    if (!isAuthenticated || !user?.id) {
      seenIdsRef.current = new Set();
      hydratedRef.current = false;
      scheduledNativeIdsRef.current = new Set();
      pendingNativeOpenRef.current = null;
      setQuietPresentation(dismissQuietNotifications());
      setUnreadCount(0);
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
        pollTimerRef.current = null;
      }
      return;
    }

    void pollNotifications();
    pollTimerRef.current = setInterval(() => {
      void pollNotifications();
    }, NOTIFICATION_POLL_MS);

    return () => {
      if (pollTimerRef.current) {
        clearInterval(pollTimerRef.current);
        pollTimerRef.current = null;
      }
    };
  }, [isAuthenticated, pollNotifications, user?.id]);

  useEffect(() => {
    if (!isAuthenticated || !user?.id) {
      socketRef.current?.disconnect();
      socketRef.current = null;
      return;
    }

    const token = getAccessToken();
    if (!token) return;

    const activeUserId = user.id;
    const socket = io(`${SOCKET_ORIGIN}/notifications`, {
      auth: { token: `Bearer ${token}` },
      transports: ["websocket", "polling"],
      reconnection: true,
      reconnectionDelay: 2500,
      reconnectionAttempts: Infinity,
      timeout: 12000,
    });

    socket.on("connect", () => {
      void pollNotifications();
    });

    socket.on("notification.new", (payload: RealtimeNotificationPayload) => {
      const notification = notificationFromRealtimePayload(
        payload,
        activeUserId,
      );
      if (!notification) return;

      const inserted = enqueueLiveNotification(notification);
      if (inserted) {
        setUnreadCount((current) => current + 1);
      }
    });

    socketRef.current = socket;

    return () => {
      socket.disconnect();
      if (socketRef.current === socket) {
        socketRef.current = null;
      }
    };
  }, [enqueueLiveNotification, isAuthenticated, pollNotifications, user?.id]);

  useEffect(() => {
    if (!isAuthenticated || role !== "student") return;

    void syncStudentReminderNotifications();
    const interval = setInterval(() => {
      void syncStudentReminderNotifications();
    }, STUDENT_REMINDER_POLL_MS);

    return () => {
      clearInterval(interval);
    };
  }, [isAuthenticated, role, syncStudentReminderNotifications]);

  useEffect(() => {
    if (!isAuthenticated || role !== "teacher") return;

    void syncTeacherReminderNotifications();
    const interval = setInterval(() => {
      void syncTeacherReminderNotifications();
    }, TEACHER_REMINDER_POLL_MS);

    return () => {
      clearInterval(interval);
    };
  }, [isAuthenticated, role, syncTeacherReminderNotifications]);

  useEffect(() => {
    if (!isAuthenticated || !user?.id) return;

    const subscription = AppState.addEventListener("change", (nextState) => {
      const previousState = appStateRef.current;
      appStateRef.current = nextState;

      if (
        (previousState === "background" || previousState === "inactive") &&
        nextState === "active"
      ) {
        clearLocalReminderSeenKeys();
        void pollNotifications();
        void syncStudentReminderNotifications();
        void syncTeacherReminderNotifications();
        void syncPushDevice();
      }
    });

    return () => {
      subscription.remove();
    };
  }, [
    clearLocalReminderSeenKeys,
    isAuthenticated,
    pollNotifications,
    syncPushDevice,
    syncStudentReminderNotifications,
    syncTeacherReminderNotifications,
    user?.id,
  ]);

  useEffect(() => {
    if (!isAuthenticated || !user?.id) return;

    void ensureNativeNotificationsReady();

    const handleResponse = (response: Notifications.NotificationResponse) => {
      const notification = notificationFromNativeData(
        response.notification.request.content.data,
      );
      if (!notification) return;
      openOrDeferNativeNotification(notification);
    };

    const subscription =
      Notifications.addNotificationResponseReceivedListener(handleResponse);

    void Notifications.getLastNotificationResponseAsync()
      .then((response) => {
        if (!response) return;
        handleResponse(response);
        if (
          typeof Notifications.clearLastNotificationResponseAsync === "function"
        ) {
          return Notifications.clearLastNotificationResponseAsync();
        }
        return undefined;
      })
      .catch(() => {
        // Missing or stale launch notifications should not block the app shell.
      });

    return () => {
      subscription.remove();
    };
  }, [
    ensureNativeNotificationsReady,
    isAuthenticated,
    openOrDeferNativeNotification,
    user?.id,
  ]);

  useEffect(() => {
    if (!isAuthenticated || nativeDeniedRef.current) return;

    void Notifications.setBadgeCountAsync(Math.max(0, unreadCount)).catch(
      () => {
        // Some Android launchers do not support badges; the in-app count remains authoritative.
      },
    );
  }, [isAuthenticated, unreadCount]);

  useEffect(() => {
    if (!quietPresentation.visible) {
      const pending = pendingNativeOpenRef.current;
      if (pending && navigateToNotification(pending, role)) {
        pendingNativeOpenRef.current = null;
      }
    }
  }, [quietPresentation.visible, role]);

  const value = useMemo(
    () => ({
      unreadCount,
      dismissActive,
    }),
    [dismissActive, unreadCount],
  );

  return (
    <LiveNotificationContext.Provider value={value}>
      <View style={{ flex: 1 }}>
        {children}
        {quietPresentation.visible ? (
          <View
            pointerEvents="box-none"
            style={{
              position: "absolute",
              top: insets.top + 8,
              left: 10,
              right: 10,
              zIndex: 1000,
              elevation: 1000,
            }}
          >
            <Animated.View
              style={{ opacity, transform: [{ translateY: slide }] }}
            >
              <QuietNotificationBanner
                count={Math.max(unreadCount, quietPresentation.count)}
                hasUnread={unreadCount > 0}
                onDismiss={dismissActive}
                onView={openNotificationCenter}
              />
            </Animated.View>
          </View>
        ) : null}
      </View>
    </LiveNotificationContext.Provider>
  );
}
