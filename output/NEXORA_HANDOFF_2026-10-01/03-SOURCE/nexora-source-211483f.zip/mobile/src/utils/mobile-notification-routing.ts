import type { MobileNotification } from "../types/notification";
import {
  resolveAllowedMobileDestination,
  type MobileDeepLinkRole,
  type MobileDeepLinkTarget,
} from "../navigation/linking";

type NavigateFn = (name: string, params?: unknown) => void;

export type MobileNotificationAction = {
  routeName: string;
  params?: unknown;
  fallbackRouteName: string;
  fallbackParams?: unknown;
  requiresReference: boolean;
  kind:
    | "assessment"
    | "announcement"
    | "discussion"
    | "grade"
    | "intervention"
    | "extraction"
    | "history";
  label: string;
};

const AT_RISK_TERMS = ["at risk", "at-risk", "flagged"];
const INTERVENTION_ALERT_TERMS = ["intervention", "support plan"];
const BLUE_REMINDER_TYPES = new Set([
  "student_pending_task_reminder",
  "student_pending_intervention_reminder",
]);
const BLUE_INTERVENTION_TERMS = [
  "checklist",
  "learner path",
  "learners path",
  "assigned path",
  "pending intervention",
];
const ASSESSMENT_TYPES = new Set([
  "assessment_assigned",
  "assessment_due",
  "assessment_graded",
  "student_pending_task_reminder",
]);

function normalizeText(value: unknown) {
  if (value === null || value === undefined) return "";
  return String(value).trim().toLowerCase();
}

function mainTabAction(
  tabName: string,
  label: string,
  kind: MobileNotificationAction["kind"],
): MobileNotificationAction {
  return {
    routeName: "MainTabs",
    params: { screen: tabName },
    fallbackRouteName: "MainTabs",
    fallbackParams: { screen: tabName },
    requiresReference: false,
    kind,
    label,
  };
}

function teacherDrawerAction(
  screen: string,
  label: string,
  kind: MobileNotificationAction["kind"],
  params?: unknown,
): MobileNotificationAction {
  const drawerParams = params === undefined ? { screen } : { screen, params };
  return {
    routeName: "TeacherDrawer",
    params: drawerParams,
    fallbackRouteName: "TeacherDrawer",
    fallbackParams: drawerParams,
    requiresReference: false,
    kind,
    label,
  };
}

function historyAction() {
  return mainTabAction("Announcements", "Open Notifications", "history");
}

function normalizeRole(role: string | null): MobileDeepLinkRole {
  const normalized = normalizeText(role);
  if (normalized === "teacher" || normalized === "admin") return normalized;
  return "student";
}

function targetAction(
  target: MobileDeepLinkTarget,
  fallback: MobileNotificationAction,
  kind: MobileNotificationAction["kind"],
  label: string,
): MobileNotificationAction {
  return {
    routeName: String(target.routeName),
    params: target.params,
    fallbackRouteName: fallback.fallbackRouteName,
    fallbackParams: fallback.fallbackParams,
    requiresReference: true,
    kind,
    label,
  };
}

export function getMobileNotificationMessage(
  notification: Pick<MobileNotification, "message" | "body">,
) {
  const message = notification.message?.trim();
  if (message) return message;
  return notification.body?.trim() || "A new update is available.";
}

export function isMobileInterventionAlertNotification(
  notification: Pick<MobileNotification, "type" | "title" | "message" | "body">,
) {
  if (BLUE_REMINDER_TYPES.has(notification.type)) return false;

  const joined = normalizeText(
    `${notification.type} ${notification.title} ${notification.message ?? ""} ${notification.body ?? ""}`,
  );

  if (AT_RISK_TERMS.some((term) => joined.includes(term))) return true;
  if (BLUE_INTERVENTION_TERMS.some((term) => joined.includes(term)))
    return false;
  return INTERVENTION_ALERT_TERMS.some((term) => joined.includes(term));
}

export function resolveMobileNotificationAction(
  notification: MobileNotification,
  role: string | null,
): MobileNotificationAction {
  const normalizedRole = normalizeText(role);
  const mobileRole = normalizeRole(role);
  const referenceId = notification.referenceId || undefined;
  const rawClassId = notification.metadata?.classId;
  const classId =
    typeof rawClassId === "string" && rawClassId.trim()
      ? rawClassId
      : undefined;

  if (notification.type === "student_pending_intervention_reminder") {
    return {
      routeName: "LXP",
      params: referenceId
        ? { classId: referenceId, tab: "paths" }
        : { tab: "paths" },
      fallbackRouteName: "LXP",
      fallbackParams: { tab: "paths" },
      requiresReference: false,
      kind: "intervention",
      label: "Open Learners Path",
    };
  }

  if (notification.type === "teacher_pending_intervention_reminder") {
    return teacherDrawerAction(
      "TeacherInterventions",
      "Open Interventions",
      "intervention",
      referenceId ? { classId: referenceId } : undefined,
    );
  }

  if (isMobileInterventionAlertNotification(notification)) {
    if (normalizedRole === "teacher" || normalizedRole === "admin") {
      const fallback = teacherDrawerAction(
        "TeacherInterventions",
        "Open Intervention",
        "intervention",
      );
      const target = referenceId
        ? resolveAllowedMobileDestination(
            { kind: "intervention", resourceId: referenceId },
            mobileRole,
          )
        : null;
      if (target) {
        return targetAction(
          target,
          fallback,
          "intervention",
          "Open Intervention",
        );
      }
      return {
        routeName: "TeacherDrawer",
        params: { screen: "TeacherInterventions" },
        fallbackRouteName: "TeacherDrawer",
        fallbackParams: { screen: "TeacherInterventions" },
        requiresReference: false,
        kind: "intervention",
        label: "Open Intervention",
      };
    }

    return {
      routeName: "LXP",
      params: { tab: "case" },
      fallbackRouteName: "LXP",
      fallbackParams: { tab: "paths" },
      requiresReference: false,
      kind: "intervention",
      label: "Open Learners Path",
    };
  }

  if (ASSESSMENT_TYPES.has(notification.type)) {
    const fallback =
      mobileRole === "student"
        ? {
            routeName: "AssessmentHistory",
            fallbackRouteName: "AssessmentHistory",
            requiresReference: false,
            kind: "assessment" as const,
            label: "Open Assessment",
          }
        : teacherDrawerAction("Assessments", "Open Assessment", "assessment");
    const target = referenceId
      ? resolveAllowedMobileDestination(
          { kind: "assessment", resourceId: referenceId },
          mobileRole,
        )
      : null;
    if (target) {
      return targetAction(target, fallback, "assessment", "Open Assessment");
    }
    return fallback;
  }

  if (notification.type === "announcement_posted") {
    if (normalizedRole === "teacher") {
      if (classId) {
        return {
          routeName: "TeacherClassDetail",
          params: {
            classId,
            initialTab: "announcements",
            announcementId: referenceId,
            source: "announcements",
          },
          fallbackRouteName: "TeacherDrawer",
          fallbackParams: { screen: "TeacherAnnouncements" },
          requiresReference: false,
          kind: "announcement",
          label: "Open Class Announcement",
        };
      }
      return teacherDrawerAction(
        "TeacherAnnouncements",
        "Open Announcements",
        "announcement",
      );
    }
    if (classId) {
      const target = resolveAllowedMobileDestination(
        { kind: "class", resourceId: classId },
        mobileRole,
      );
      if (mobileRole === "admin" && target) {
        return {
          routeName: String(target.routeName),
          params: {
            ...(target.params as Record<string, unknown>),
            initialTab: "announcements",
            announcementId: referenceId,
            source: "announcements",
          },
          fallbackRouteName: "MainTabs",
          fallbackParams: { screen: "AdminAnnouncements" },
          requiresReference: false,
          kind: "announcement",
          label: "Open Class Announcement",
        };
      }
      return {
        routeName: "ClassDetail",
        params: {
          classId,
          initialTab: "announcements",
          announcementId: referenceId,
          source: "announcements",
        },
        fallbackRouteName: "MainTabs",
        fallbackParams: { screen: "Announcements" },
        requiresReference: false,
        kind: "announcement",
        label: "Open Class Announcement",
      };
    }
    return mainTabAction("Announcements", "Open Announcements", "announcement");
  }

  if (
    notification.type === "discussion_thread_posted" ||
    notification.type === "discussion_comment_posted"
  ) {
    return mainTabAction("Classes", "Open Classes", "discussion");
  }

  if (notification.type === "grade_updated") {
    if (normalizedRole === "teacher") {
      return teacherDrawerAction(
        "TeacherClassRecord",
        "Open Class Record",
        "grade",
      );
    }
    if (mobileRole === "admin") {
      return mainTabAction("AdminClassRecord", "Open Class Record", "grade");
    }
    const target = resolveAllowedMobileDestination(
      { kind: "performance" },
      mobileRole,
    );
    return {
      routeName: String(target?.routeName || "Performance"),
      params: target?.params,
      fallbackRouteName: "Performance",
      requiresReference: false,
      kind: "grade",
      label: "Open Performance",
    };
  }

  if (
    notification.type === "extraction_completed" ||
    notification.type === "extraction_failed"
  ) {
    const primaryRouteName =
      normalizedRole === "teacher" ? "TeacherDrawer" : "MainTabs";
    return {
      routeName: referenceId ? "TeacherExtractionDetail" : primaryRouteName,
      params: referenceId
        ? { extractionId: referenceId }
        : { screen: "Classes" },
      fallbackRouteName: primaryRouteName,
      fallbackParams: { screen: "Classes" },
      requiresReference: Boolean(referenceId),
      kind: "extraction",
      label: "Open Extraction",
    };
  }

  return normalizedRole === "teacher"
    ? teacherDrawerAction("Home", "Open Teacher Home", "history")
    : historyAction();
}

async function validateMobileNotificationAction(
  action: MobileNotificationAction,
  notification: MobileNotification,
) {
  if (!action.requiresReference) return true;
  const referenceId = notification.referenceId;
  if (!referenceId) return false;

  if (action.kind === "assessment") {
    const { assessmentsApi } = await import("../api/services/assessments");
    await assessmentsApi.getById(referenceId);
    return true;
  }

  if (action.kind === "intervention") {
    const { lxpApi } = await import("../api/services/lxp");
    await lxpApi.getTeacherCaseDetail(referenceId);
    return true;
  }

  if (action.kind === "extraction") {
    const { extractionsApi } = await import("../api/services/extractions");
    await extractionsApi.getById(referenceId);
    return true;
  }

  if (action.kind === "discussion") {
    const { classesApi } = await import("../api/services/classes");
    await classesApi.getById(referenceId);
    return true;
  }

  return true;
}

export async function openMobileNotification(
  notification: MobileNotification,
  role: string | null,
  navigate: NavigateFn,
) {
  const action = resolveMobileNotificationAction(notification, role);

  try {
    const valid = await validateMobileNotificationAction(action, notification);
    if (valid) {
      navigate(action.routeName, action.params);
      return;
    }
  } catch {
    // Fall through to the known-safe fallback route.
  }

  navigate(action.fallbackRouteName, action.fallbackParams);
}
